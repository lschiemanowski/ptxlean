Implemented plain `prmt.b32` in [Ptx/Prmt32.lean](/home/lothar/workspace/ptxlean/.formalization-runs/luna/attempts/prmt-001/worktree/Ptx/Prmt32.lean). The computation follows the required output-bit law, with the supplied Pure32 execution and ScalarText interfaces.

Both requested checks passed:

- `lake build Ptx.Prmt32`
- `lake env lean formalization/checks/prmt-v1.lean`

The unchanged concrete checker also passed. The pinned PTX source hash matched the contract.

I audited the exported proofs with `#print axioms`. They depend only on the allowed standard axioms: `propext`, `Quot.sound`, and, for `Text.decode_iff`, `Classical.choice`. No blockers found. No files outside the allowed path were modified.