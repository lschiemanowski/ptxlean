from pathlib import Path
import json,re,subprocess,sys,hashlib
root=Path.cwd();out=root/'.formalization-runs/prmt-v1';work=out/'preflight-worktree'
sys.path.insert(0,'scripts');from check_implemented_forms import declaration_sites;from worker_replay import audit_dependencies,scan
# Generate public universal signatures with a delimiter-aware split.
c=Path('formalization/contracts/prmt-v1.md').read_text();block=c.split('```lean\n',1)[1].split('```',1)[0];theorems=re.findall(r'^theorem (\S+)\s+([\s\S]*?)(?=^theorem |\Z)',block,re.M)
prefix='import Ptx.Prmt32\nopen Ptx\nset_option linter.unusedVariables false\nset_option maxRecDepth 4096\nnamespace Ptx.Scalar.Prmt32.Acceptance\n\n';univ=prefix
for name,s in theorems:
 s=s.strip();depth=0
 for i,ch in enumerate(s):
  if ch in '([{':depth+=1
  if ch in ')]}':depth-=1
  if ch==':' and depth==0:break
 else:raise ValueError(name)
 univ+='example : ∀ '+s[:i].rstrip()+','+s[i+1:]+'\n  := @'+name+'\n\n'
con=Path('formalization/checks/prmt-concrete-v1.lean').read_text()
# Exact expectations from separate byte-level arithmetic, all selector codes and output positions.
exec(Path('/tmp/ptx_prmt_setup.py').read_text().split('def oracle',1)[1].split('cases=',1)[0].join(['def oracle','']),globals())
extra=''
for j in range(4):
 for sel in range(16):
  a=0x7f80ff00;b=0x80ff007f;ctl=(0x3210 & ~(15 << (4*j))) | (sel <<(4*j))
  extra+=f'example : compute .permute {hex(a)} {hex(b)} {hex(ctl)} = ({hex(oracle(a,b,ctl))} : Word) := by decide\n'
con=con.replace('end Ptx.Scalar.Prmt32.Acceptance',extra+'end Ptx.Scalar.Prmt32.Acceptance');Path('formalization/checks/prmt-concrete-v1.lean').write_text(con);Path('formalization/checks/prmt-v1.lean').write_text(univ+con[len(prefix):])
if not work.exists():subprocess.run(['git','worktree','add','--detach',str(work),'HEAD'],check=True,capture_output=True)
fixture=(out/'Prmt32-fixture.lean').read_text();names=[n for n,k,_ in declaration_sites(fixture) if k in ('def','theorem')];audit=out/'audit.lean';audit.write_text('import Ptx.Prmt32\n'+''.join('#print axioms '+n+'\n' for n in names));records=[]
cases={'control':fixture,'swap_sources':fixture.replace('then a else b','then b else a'),'omit_sign':fixture.replace('(if 8 ≤ selector then 7 else i.val % 8)','(i.val % 8)').replace('(if 8 ≤ selector then 7 else bit % 8)','(bit % 8)'),'omit_selector_mask':fixture.replace(') % 16',')')}
for label,body in cases.items():
 (out/(label+'.lean')).write_text(body);(work/'Ptx/Prmt32.lean').write_text(body)
 def run(args,stem,success=True):
  r=subprocess.run(args,cwd=work,capture_output=True,text=True);log=r.stdout+r.stderr;(out/(label+'-'+stem+'.log')).write_text(log);assert (r.returncode==0)==success,(label,stem,log[-4000:]);return log
 run(['lake','build','Ptx.Prmt32'],'build');log=run(['lake','env','lean',str(audit)],'audit');audit_dependencies(log,names);scan([work/'Ptx/Prmt32.lean'])
 log=run(['lake','env','lean',str(root/'formalization/checks/prmt-concrete-v1.lean')],'concrete',label=='control')
 if label!='control':assert 'decide' in log and 'false' in log
 run(['lake','env','lean',str(root/'formalization/checks/prmt-v1.lean')],'universal',label=='control')
 records.append({'case':label,'sha256':hashlib.sha256(body.encode()).hexdigest(),'build':'pass','audit':'pass','checks':'pass' if label=='control' else 'reject','declarations':names});print(label,'verified',flush=True)
(out/'preflight.json').write_text(json.dumps({'schema_version':1,'records':records,'qualification':'Coordinator-written reference and compiling mutants were private and excluded from worker base. Independent byte-level oracle supplies concrete expectations; formal universal law is provided to worker. Preflight draft/checker corrections occurred before freeze.'},indent=2)+'\n')
