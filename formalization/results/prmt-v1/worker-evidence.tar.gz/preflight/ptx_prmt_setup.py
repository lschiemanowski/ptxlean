from pathlib import Path
import json,re,time
out=Path('.formalization-runs/prmt-v1');(out/'start.json').write_text(json.dumps({'epoch':time.time(),'note':'Start of coordinator preparation wall interval, including waits; not active attention.'})+'\n')
meaning='''Select each of four output bytes from the eight bytes in the two input words.
Source bytes zero through three belong to the first word, and four through seven
to the second; byte zero is least significant. Each output byte uses one four-bit
selector from the control word, starting with the low four bits for output byte
zero. The selector's low three bits choose a source byte; its high bit chooses
whether to copy that byte or repeat its sign bit over the output byte. Only the
low sixteen control bits matter. All input words and control patterns are allowed.
Only plain prmt.b32 is selected; all six specialized modes are excluded.
Introduced PTX 2.0; requires sm_20.'''
law='''(let selector := (c.toNat / 2 ^ (4 * (bit / 8))) % 16
     let source := if selector % 8 < 4 then a else b
     source.getLsbD (8 * (selector % 4) + (if 8 ≤ selector then 7 else bit % 8)))'''
c=Path('formalization/contracts/lop3-v1.md').read_text().replace('lop3','prmt').replace('Lop3','Prmt32').replace('logic-and-shift-instructions-prmt','data-movement-and-conversion-instructions-prmt').replace('SM >= 50','SM >= 20').replace('50 ≤ target.sm','20 ≤ target.sm').replace('abbrev Operation := BitVec 8','inductive Operation where\n  | permute\n  deriving DecidableEq, Repr').replace('third','control')
a=c.index('Apply an eight-entry');b=c.index('\n\nThe exact slice',a);c=c[:a]+meaning+c[b:]
a=c.index('The operation is the immediate');b=c.index('Text.decode accepts exactly',a);c=c[:a]+'''Each operation has exactly its listed spelling.
Text.encode emits the destination register followed by three word operands (first,
second, control); all three can be registers or already converted immediates.
'''+c[b:]
a=c.index('    (compute op a b c).getLsbD bit =');b=c.index('\n\ntheorem results_iff',a);c=c[:a]+'    (compute op a b c).getLsbD bit = '+law+c[b:]
# Module spelling references are not the lower-case task identifier.
c=c.replace('Ptx/Prmt32.lean','Ptx/Prmt32.lean').replace('Ptx.Prmt32','Ptx.Prmt32')
c+='''\nThe existing Ptx.BitVecProof module and its examples/bitvector_proofs.lean and
docs/formalization/bitvector-proofs.md guide are available unchanged. No new
instruction-specific proof hints or computation body are supplied in this first
invocation. Derive and prove your implementation under the fixed output law.
Do not inspect private coordinator fixtures or unrelated archived trial fixtures.
'''
Path('formalization/contracts/prmt-v1.md').write_text(c)
# Independent universal signature driver is generated from the required theorem statements.
block=c.split('```lean\n',1)[1].split('```',1)[0];theorems=re.findall(r'^theorem (\S+)\s+([\s\S]*?)(?=^theorem |\Z)',block,re.M)
assert len(theorems)==18,len(theorems)
univ='import Ptx.Prmt32\nopen Ptx\nset_option linter.unusedVariables false\nset_option maxRecDepth 4096\nnamespace Ptx.Scalar.Prmt32.Acceptance\n\n'
for name,statement in theorems:
 # Replace the first top-level result colon (at line start or after binder group).
 s=statement.strip();pos=s.index(' :\n') if ' :\n' in s else s.index(' : ')
 s=s[:pos]+','+s[pos+2:];univ+='example : ∀ '+s+'\n  := @'+name+'\n\n'
# Project-authored examples use a separate byte-level integer oracle below.
def oracle(a,b,c):
 src=[(a>>(8*i))&255 for i in range(4)]+[(b>>(8*i))&255 for i in range(4)]
 result=0
 for j in range(4):
  sel=(c>>(4*j))&15;v=src[sel&7]
  if sel&8:v=255 if v&128 else 0
  result|=v<<(8*j)
 return result
cases=[(0x44332211,0x88776655,c) for c in [0x3210,0x7654,0x0123,0x4567,0x5410,0x7777,0x8000,0xFEDC,0xBA98,0xFFFF,0xABCD5410]]
cases += [(0x7f80ff00,0x80ff007f,c) for c in [0x3210,0xBA98,0xFEDC,0xF80B,0x12340000,0xffffffff]]
con='import Ptx.Prmt32\nopen Ptx\nset_option linter.unusedVariables false\nset_option maxRecDepth 4096\nnamespace Ptx.Scalar.Prmt32.Acceptance\n\n'
for a,b,c0 in cases:con+=f'example : compute .permute {hex(a)} {hex(b)} {hex(c0)} = ({hex(oracle(a,b,c0))} : Word) := by decide\n'
# Exhaust all four-bit selector values and target byte positions on distinct signed/unsigned bytes.
con+='''\nexample : SupportedTarget ⟨94,20⟩ := by constructor <;> decide
example : ¬ SupportedTarget ⟨94,19⟩ := by intro h; have := h.2; omega
example : ¬ SupportedTarget ⟨93,90⟩ := by intro h; have := h.1; contradiction
example : Text.decode ⟨.pred 3 false, "prmt.b32", [.word (.reg 0), .word (.reg 0), .word (.reg 0), .word (.reg 0)]⟩ = .ok (⟨.pred 3 false, .permute, 0, .reg 0, .reg 0, .reg 0⟩ : Instr) := by rfl
example : Text.decode ⟨.always, "prmt.b32", []⟩ = .error (.invalidOperands "prmt.b32") := by rfl
example : Text.decode ⟨.always, "prmt.b32", [.word (.imm 0), .word (.reg 1), .word (.reg 2), .word (.reg 3)]⟩ = .error (.invalidOperands "prmt.b32") := by rfl
example : Text.decode ⟨.always, "prmt.b32", [.word (.reg 0), .word (.reg 1), .word (.reg 2), .word (.imm 0xffffffff)]⟩ = .ok (⟨.always, .permute, 0, .reg 1, .reg 2, .imm 0xffffffff⟩ : Instr) := by rfl
'''
for spelling in ['prmt.b32.f4e','prmt.b32.b4e','prmt.b32.rc8','prmt.b32.ecl','prmt.b32.ecr','prmt.b32.rc16','prmt.b64','unknown']:
 con+=f'example : Text.decode ⟨.always, "{spelling}", []⟩ = .error (.unsupportedMnemonic "{spelling}") := by rfl\n'
con+='''private def incoming : Scalar.State := ⟨7, fun _ => 1, fun _ => 0, fun _ => true, [11,22]⟩
private def tested : Instr := ⟨.pred 3 true, .permute, 0, .reg 0, .reg 0, .reg 0⟩
example : Eval tested incoming (Pure32.write incoming 0 (result tested incoming)) (occurrence incoming tested true) := (eval_true_iff tested incoming _ _ (by rfl)).mpr ⟨rfl,rfl⟩
example : (occurrence incoming tested true).reads = [.predicate 3, .word 0, .word 0, .word 0] := by rfl
private def skipped : Instr := {tested with guard := .pred 3 false}
example : Eval skipped incoming {incoming with pc := 8} (occurrence incoming skipped false) := (eval_false_iff skipped incoming _ _ (by rfl)).mpr ⟨rfl,rfl⟩
example : (occurrence incoming skipped false).reads = [.predicate 3] := by rfl
'''
Path('formalization/checks/prmt-concrete-v1.lean').write_text(con+'end Ptx.Scalar.Prmt32.Acceptance\n')
Path('formalization/checks/prmt-v1.lean').write_text(univ+con.split('namespace Ptx.Scalar.Prmt32.Acceptance\n\n')[1]+'end Ptx.Scalar.Prmt32.Acceptance\n')
# Private reference fixture: not part of the worker task/base.
f=Path('.formalization-runs/derived-v1/Lop3-fixture.lean').read_text().replace('Lop3','Prmt32').replace('third','control').replace('50 ≤ target.sm','20 ≤ target.sm').replace('abbrev Operation := BitVec 8','inductive Operation where\n  | permute\n  deriving DecidableEq, Repr')
a=f.index('def compute ');b=f.index('\ndef family',a)
flaw=law.replace('bit','i.val');f=f[:a]+f'''def compute (_op : Operation) (a b c : Word) : Word :=
  (BitVec.ofBoolListLE (List.ofFn (fun i : Fin 32 => {flaw}))).cast (by simp)
'''+f[b:]
a=f.index('    (compute op a b c).getLsbD bit =');b=f.index(' := by',a);f=f[:a]+'    (compute op a b c).getLsbD bit = '+law+f[b:]
a=f.index('namespace Text');old=Path('Ptx/Bfi32.lean').read_text();text=old[old.index('namespace Text'):].replace('Bfi32','Prmt32').replace('bfi.b32','prmt.b32').replace('.word i.insert, .word i.base, .word i.position, .word i.length','.word i.first, .word i.second, .word i.control').replace('.word insert, .word base, .word position, .word length','.word first, .word second, .word control').replace('.insert, destination, insert, base, position, length','.permute, destination, first, second, control');f=f[:a]+text
(out/'Prmt32-fixture.lean').write_text(f)
# Description first; no accepted implementation until worker/review completes.
Path('stratic/descriptions/prmt.md').write_text('''# Byte permutation

A byte is eight bits. Plain `prmt.b32` builds a 32-bit result by selecting four
bytes from two input words. Bytes zero through three come from the first word,
starting at its least significant byte; bytes four through seven come from the
second word in the same order.

Each output byte has a four-bit selector in the control word. Its low three bits
choose the source byte. Its remaining bit selects ordinary copying or sign
replication: filling the output byte with eight copies of the source byte's most
significant bit, producing either zero or 255. The least significant selector
controls the least significant output byte. Only the low sixteen control bits
are used. The control can be a register or an immediate value; it is not limited
to sixteen-bit input values.

All sources are read before the destination is written, so registers may repeat
or overlap the destination. A true-or-false guard controls execution. Skipping
advances the program counter without a write; enabled execution changes only the
destination and that counter. The execution record retains the guard read and
ordered source reads, including repeats, or only the guard read when skipped.
Memory, address registers, predicate registers and other word registers are preserved.

The selected form was introduced in PTX 2.0 and requires SM 20 or higher. Fetched
steps select ISA exactly 9.4 and a numeric SM floor of 20, even when skipped.
This is a feature threshold, not validation of architecture names. The typed
decoder accepts exactly `prmt.b32`, a word-register destination and three word
operands, preserving the guard. Immediates have already been converted to words;
register declarations and raw PTX text are outside this decoder.

The six specialized modes have different selection rules and remain excluded.
Proofs must establish the output-bit law for every input, including arbitrary
upper control bits, and exact guarded execution and decoding. These Lean facts
are separate from source fidelity and do not establish hardware conformance.
''')
d={'id':'prmt','parent':{'description':'pure-instruction-families','passage':{'quote':'Family source proofs and text decoders can reuse this\nmechanism without modifying the scalar state or duplicating its transition\nrules.'}},'summary':['Select each output byte from two words, with optional replication of the selected byte\'s sign bit.','Use the low sixteen control bits while admitting every 32-bit control value, including registers and immediates.','Preserve guarded execution and exact typed decoding for plain prmt.b32 at ISA 9.4 and SM at least 20; specialized modes remain excluded.'],'realization':'unimplemented','remaining':'Source-derived contract and independent checks are being prepared; worker completion, fresh replay and separate semantic review remain required.','links':[]};Path('stratic/descriptions/prmt.json').write_text(json.dumps(d,indent=2)+'\n')
print('Generated contract, 18 universal signatures, concrete checks, description and private reference')
