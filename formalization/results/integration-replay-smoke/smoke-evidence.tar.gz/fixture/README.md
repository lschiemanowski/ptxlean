# Synthetic integration replay smoke

This is a coordinator-authored infrastructure fixture, not a Luna attempt.
It makes zero model calls and does not reserve a campaign call. Its tiny theorem
uses the already proved binary32 encoding roundtrip and adds no PTX semantics.
The receipt marks fixture preparation as completed, not a worker execution.
The immutable driver is separately hashed. Fresh replay has not run at preparation.
Inspect fresh-replay/result.json after explicitly running the recorded command.
A passing result establishes only this plumbing smoke, not instruction correctness,
source fidelity, general dependency isolation, or smaller-model productivity.

## Completed smoke

The subsequent fresh replay passed; see `smoke-result.json` and
`fresh-replay/result.json` for exact timing, hashes and command receipts.
The official mathlib cache command succeeded, then requested modules, driver and
axiom audit passed with only standard Lean axioms. Final source and dependency
checks passed. Candidate ledger refresh remains explicitly deferred; this is
not instruction acceptance. No model call or campaign reservation was made.
