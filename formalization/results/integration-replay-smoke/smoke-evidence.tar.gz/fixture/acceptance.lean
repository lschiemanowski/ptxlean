import PtxBinary32.ReplaySmoke

example (word : Ptx.Word) :
    Ptx.Binary32.encode (Ptx.Binary32.decode word) = word :=
  Ptx.Binary32.ReplaySmoke.roundtrip word

example : Ptx.Binary32.encode (Ptx.Binary32.decode (0 : Ptx.Word)) = 0 := rfl
example : Ptx.Binary32.encode (Ptx.Binary32.decode (0xffffffff : Ptx.Word)) = 0xffffffff := rfl
