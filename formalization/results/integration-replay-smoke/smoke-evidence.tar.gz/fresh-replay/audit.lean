import PtxBinary32.ReplaySmoke
#print axioms Ptx.Binary32.ReplaySmoke.roundtrip
