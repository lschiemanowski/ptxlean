#!/usr/bin/env python3
"""Prepare a synthetic replay fixture, never a worker invocation or acceptance.

This script creates one detached fixture worktree and a hand-authored patch.
It does not call replay, a model, a campaign ledger, or a build command.
"""
import argparse
import json
from pathlib import Path
import shlex
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('base_commit')
parser.add_argument('--root', type=Path, default=Path('/home/lothar/workspace/ptxlean'))
parser.add_argument('--destination', type=Path, required=True)
args = parser.parse_args()
root = args.root.resolve()
sys.path.insert(0, str(root / 'scripts'))
import worker_run as w
import worker_replay as replay

project = 'integration/torchlean'
output = project + '/PtxBinary32/ReplaySmoke.lean'
module = 'PtxBinary32.ReplaySmoke'
declaration = 'Ptx.Binary32.ReplaySmoke.roundtrip'
# Require the promised numerical foundation in the exact base, not live files.
foundation = w.git(root, 'show', args.base_commit + ':' + project + '/PtxBinary32.lean')
config = w.git(root, 'show', args.base_commit + ':' + project + '/lakefile.toml')
if b'name = "PtxBinary32"' not in config or b'theorem encode_decode' not in foundation:
    raise ValueError('Base does not contain the binary32 foundation/library')
paths = [prefix + name for prefix in ['', project + '/']
         for name in ['lean-toolchain', 'lakefile.toml', 'lake-manifest.json']]
paths.append(project + '/PtxBinary32.lean')
task = {
    'schema_version': 1, 'id': 'synthetic-integration-replay-smoke',
    'base_commit': args.base_commit, 'replay_project': project,
    'allowed_paths': [output],
    'sources': [{'path': p, 'sha256': w.sha(w.git(root, 'show', args.base_commit + ':' + p))}
                for p in paths],
    'prompt': 'Synthetic infrastructure smoke fixture only: re-export the imported binary32 roundtrip theorem. No instruction formalization or model-generated work.',
    'provenance': {'kind': 'coordinator-authored-synthetic-fixture', 'model_calls': 0,
                   'campaign_calls': 0, 'not_worker_evaluation': True},
}
w.validate_task(task, root)
destination = args.destination.resolve()
destination.mkdir(parents=True, exist_ok=False)
attempt = destination / 'synthetic-attempt'
attempt.mkdir()
worktree = attempt / 'fixture-worktree'
w.git(root, 'worktree', 'add', '--detach', str(worktree), args.base_commit)
path = worktree / output
path.parent.mkdir(parents=True, exist_ok=True)
path.write_text('''import PtxBinary32

namespace Ptx.Binary32.ReplaySmoke

/-- Synthetic replay plumbing check; the imported theorem supplies the proof. -/
theorem roundtrip (word : Ptx.Word) :
    Ptx.Binary32.encode (Ptx.Binary32.decode word) = word :=
  Ptx.Binary32.encode_decode word

end Ptx.Binary32.ReplaySmoke
''')
patch, boundary = w.patch_and_boundary(worktree, args.base_commit, [output], project)
if not boundary['eligible_for_review']:
    raise ValueError('Synthetic fixture has unexpected edits')
w.atomic_json(attempt/'task.json', task)
(attempt/'candidate.patch').write_bytes(patch)
receipt = {
    'attempt': 'synthetic-integration-smoke', 'base_commit': args.base_commit,
    'task_sha256': w.sha(json.dumps(task, sort_keys=True).encode()),
    'patch_sha256': w.sha(patch), 'boundary': boundary,
    'state': 'completed', 'finished_at': w.now(),
    'synthetic': True, 'provenance': task['provenance'],
    'completion_meaning': 'Hand-authored fixture prepared, not a worker or model process result.',
    'acceptance': 'not_applicable_synthetic_smoke',
}
w.atomic_json(attempt/'receipt.json', receipt)
driver = destination/'acceptance.lean'
driver.write_text('''import PtxBinary32.ReplaySmoke

example (word : Ptx.Word) :
    Ptx.Binary32.encode (Ptx.Binary32.decode word) = word :=
  Ptx.Binary32.ReplaySmoke.roundtrip word

example : Ptx.Binary32.encode (Ptx.Binary32.decode (0 : Ptx.Word)) = 0 := rfl
example : Ptx.Binary32.encode (Ptx.Binary32.decode (0xffffffff : Ptx.Word)) = 0xffffffff := rfl
''')
driver.chmod(0o444)
replay.validate_attempt(attempt, root)
command = [sys.executable, str(root/'scripts/worker_replay.py'), str(attempt),
           '--root', str(root), '--destination', str(destination/'fresh-replay'),
           '--module', module, '--check', str(driver), '--audit', declaration]
w.atomic_json(destination/'fixture.json', {
    'kind': 'synthetic-integration-replay-smoke', 'model_calls': 0,
    'campaign_calls': 0, 'base_commit': args.base_commit,
    'patch_sha256': w.sha(patch), 'driver_sha256': w.sha(driver.read_bytes()),
    'preparer_sha256': w.sha(Path(__file__).read_bytes()),
    'command': command, 'executed': False,
    'scope': 'Replay plumbing/import/dependency isolation only; no instruction or productivity evidence.'})
(destination/'README.md').write_text('''# Synthetic integration replay smoke

This is a coordinator-authored infrastructure fixture, not a Luna attempt.
It makes zero model calls and does not reserve a campaign call. Its tiny theorem
uses the already proved binary32 encoding roundtrip and adds no PTX semantics.
The receipt marks fixture preparation as completed, not a worker execution.
The immutable driver is separately hashed. Fresh replay has not run at preparation.
Inspect fresh-replay/result.json after explicitly running the recorded command.
A passing result establishes only this plumbing smoke, not instruction correctness,
source fidelity, general dependency isolation, or smaller-model productivity.
''')
print(json.dumps({'prepared': str(destination), 'model_calls': 0,
                  'full_replay_executed': False, 'command': shlex.join(command)}, indent=2))
