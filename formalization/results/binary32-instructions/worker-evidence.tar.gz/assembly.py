#!/usr/bin/env python3
"""Prepare selection; finalize only after supplied integration logs and mutation pass.
Does not run inference, mutate candidate sources, or extract archives.
"""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import sys
import tarfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--root', type=Path, default=Path('/home/lothar/workspace/ptxlean'))
p.add_argument('--mutation-dir', type=Path, default=Path('/tmp/ptxlean-binary32-probe-003'))
p.add_argument('--integration-log', action='append', default=[], metavar='NAME=PATH')
p.add_argument('--finalize', action='store_true', help='Explicit coordinator signal after reviews/integration complete')
a = p.parse_args()
root = a.root.resolve()
output = root / 'formalization/results/binary32-instructions'
files = {}
sha = lambda b: hashlib.sha256(b).hexdigest()


def add(path, name):
    path = Path(path)
    if not path.is_file() or path.is_symlink():
        raise ValueError(f'Missing/nonregular evidence: {path}')
    if name in files:
        raise ValueError(f'Duplicate evidence name: {name}')
    files[name] = path


def tree(path, prefix):
    for directory, subdirs, names in os.walk(path):
        subdirs[:] = sorted(d for d in subdirs if d not in {'worktree', '.lake', '.git', '__pycache__'})
        for name in sorted(names):
            item = Path(directory) / name
            # Probe .olean files are disposable cache, not retained source/log evidence.
            if (any(part in {'.olean', '.ilean'} for part in item.suffixes)
                    or item.suffix in {'.c', '.o', '.trace', '.hash'}):
                continue
            add(item, prefix + '/' + item.relative_to(path).as_posix())


ledger_path = root / '.formalization-runs/luna/ledger.json'
ledger = json.loads(ledger_path.read_text())
assert [(x['call'], x['attempt']) for x in ledger['calls'] if x['call'] in (7, 8, 9)] == [
    (7, 'binary32-001'), (8, 'binary32-002'), (9, 'binary32-003')]
add(ledger_path, 'campaign-ledger.json')
checker = root / 'scripts/worker_replay.py'
for number in ('001', '002', '003'):
    attempt = root / ('.formalization-runs/luna/attempts/binary32-' + number)
    receipt = json.loads((attempt / 'receipt.json').read_text())
    assert receipt.get('finished_at') and receipt.get('state') in {'completed', 'failed', 'interrupted'}
    tree(attempt, 'attempts/binary32-' + number)
    replay = Path('/tmp/ptxlean-binary32-replay-' + number)
    result = json.loads((replay / 'result.json').read_text())
    assert result.get('finished_at') and result['mechanical'] == ('pass' if number == '003' else 'fail')
    assert result['checker_sha256'] == sha(checker.read_bytes()), 'Archive exact historical checker before assembly'
    assert result['patch_sha256'] == sha((attempt / 'candidate.patch').read_bytes())
    tree(replay, 'replays/binary32-' + number)

for name in ('worker_replay.py', 'worker_run.py', 'check_proofs.py', 'check_implemented_forms.py',
             'check_worker_evidence.py', 'coverage_inventory.py', 'check.sh'):
    add(root / 'scripts' / name, 'current-checkers/' + name)
for version in ('v1', 'v2'):
    for extension in ('lean', 'json'):
        name = 'binary32-instructions-' + version + '.' + extension
        add(root / 'formalization/checks' / name, 'checks/' + name)
for path in ('formalization/contracts/binary32-instructions-v1.md',
             'formalization/tasks/binary32-instructions-v1.json',
             'docs/formalization/binary32-instructions-source-review.md',
             'docs/formalization/binary32-instructions-proof-review.md'):
    add(root / path, path)
for path in sorted(Path('/tmp').glob('ptx-binary32-instructions-*.log')):
    add(path, 'independent-preflight/' + path.name)
for name in ('ptx-binary32-instruction-audit.lean', 'ptx-binary32-instruction-examples.lean',
             'ptx-binary32-instruction-review.json', 'ptx-binary32-instructions-added-audit.lean',
             'ptx-binary32-instructions-explicit-driver.lean', 'ptxlean-binary32-002.Instructions.lean'):
    add(Path('/tmp') / name, 'independent-preflight/' + name)
for name in ('ptxlean-binary32-provision.log', 'ptxlean-binary32-dispatch.log',
             'ptxlean-binary32-repair-1.log', 'ptxlean-binary32-repair-2.log',
             'ptxlean-binary32-001-elaboration.log', 'ptxlean-binary32-replay-001.log',
             'ptxlean-binary32-replay-002.log'):
    add(Path('/tmp') / name, 'coordinator/' + name)
add(Path(__file__), 'assembly.py')
for name in ('review-probes.md', 'review-probe-result.json'):
    add(output / name, 'review/' + name)

# Preserve coordinator probe setup failure and the first successful, less strict check.
for number in ('001', '002'):
    previous = Path('/tmp/ptxlean-binary32-probe-' + number)
    report = json.loads((previous / 'report.json').read_text())
    assert report.get('finished_at')
    assert sha((previous / 'harness.py').read_bytes()) == report['script_sha256']
    tree(previous, 'review-probes-' + number)

pending = []
report_path = a.mutation_dir / 'report.json'
if report_path.is_file():
    report = json.loads(report_path.read_text())
    if report.get('finished_at') and report.get('outcome', '').startswith('pass:'):
        prefix = 'review-probes-003'
        tree(a.mutation_dir, prefix)
        if prefix + '/harness.py' not in files:
            add('/tmp/ptxlean-binary32-probe.py', prefix + '/harness.py')
        assert sha(files[prefix + '/harness.py'].read_bytes()) == report['script_sha256']
    else:
        pending.append('completed passing mutation probe')
else:
    pending.append('completed passing mutation probe')
if not a.integration_log:
    pending.append('coordinator-supplied successful integration logs')
for item in a.integration_log:
    name, path = item.split('=', 1)
    assert Path(name).name == name and name, 'Use one simple log filename'
    add(path, 'integration/' + name)

if not a.finalize:
    print(json.dumps({'mode': 'selection_only', 'files': len(files), 'pending': pending,
                      'destination': str(output), 'members': sorted(files)}, indent=2))
    sys.exit(0)
if pending:
    raise ValueError('Not ready to finalize: ' + ', '.join(pending))
archive = output / 'worker-evidence.tar.gz'
manifest_path = output / 'evidence-manifest.json'
assert not archive.exists() and not manifest_path.exists(), 'Refuse to overwrite historical evidence'
# Capture bytes once; later filesystem changes cannot silently enter this archive.
contents = {name: path.read_bytes() for name, path in sorted(files.items())}
manifest = {'schema_version': 1, 'archive': archive.name, 'members': {
    name: {'sha256': sha(raw), 'bytes': len(raw)} for name, raw in contents.items()}}
output.mkdir(parents=True, exist_ok=True)
with archive.open('xb') as raw_archive:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw_archive, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as stream:
            for name, raw in contents.items():
                entry = tarfile.TarInfo(name)
                entry.size = len(raw)
                entry.mode = 0o644
                entry.mtime = 0
                stream.addfile(entry, io.BytesIO(raw))
manifest['archive_sha256'] = sha(archive.read_bytes())
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
# Expose readable proof/probe logs alongside the archive, with identical bytes.
for name, raw in contents.items():
    if name.startswith(('review-probes-', 'integration/')):
        destination = output / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            assert destination.read_bytes() == raw, f'Existing evidence differs: {name}'
        else:
            destination.write_bytes(raw)
sys.path.insert(0, str(root / 'scripts'))
from check_worker_evidence import verify
print(f'Finalized and verified {verify(manifest_path)} files: {manifest_path}')
