import PtxBinary32.Instructions
import PtxBinary32Bounds
#print axioms Ptx.Scalar.Binary32.eval_true_iff
#print axioms Ptx.Scalar.Binary32.eval_false_iff
#print axioms Ptx.Scalar.Binary32.eval_destination
#print axioms Ptx.Scalar.Binary32.eval_frame
#print axioms Ptx.Scalar.Binary32.eval_other
#print axioms Ptx.Scalar.Binary32.eval_event
#print axioms Ptx.Scalar.Binary32.eval_exists
#print axioms Ptx.Scalar.Binary32.step_origin
#print axioms Ptx.Scalar.Binary32.step_exists
#print axioms Ptx.Scalar.Binary32.step_no_fetch
#print axioms Ptx.Scalar.Binary32.step_unsupported_target
#print axioms Ptx.Scalar.Binary32.Text.decode_encode
#print axioms Ptx.Scalar.Binary32.Text.decode_iff
#print axioms Ptx.Scalar.Binary32.occurrence
#print axioms Ptx.Scalar.Binary32.SupportedTarget
#print axioms Ptx.Scalar.Binary32.Step
#print axioms Ptx.Scalar.Binary32.Text.decode
#print axioms Ptx.Scalar.Binary32.Text.encode
