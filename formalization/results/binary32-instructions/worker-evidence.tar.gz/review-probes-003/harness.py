#!/usr/bin/env python3
"""Isolated source/olean overlays; no mutation of accepted or replayed sources."""
import argparse, datetime, difflib, hashlib, json, os, re, shutil, subprocess, sys
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--root',type=Path,required=True); p.add_argument('--replay',type=Path,required=True); p.add_argument('--out',type=Path,required=True); a=p.parse_args()
root=a.root.resolve(); replay=a.replay.resolve(); out=a.out.resolve(); out.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(root/'scripts'))
from worker_replay import audit_dependencies
from check_implemented_forms import declaration_sites
sha=lambda x:hashlib.sha256(x).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
result=json.loads((replay/'result.json').read_text()); assert result['mechanical']=='pass'
project=replay/'worktree/integration/torchlean'
source=project/'PtxBinary32/Instructions.lean'; original=source.read_bytes()
driver=(root/'formalization/checks/binary32-instructions-v2.lean').read_bytes()
names=[n for n,k,line in declaration_sites(original.decode())]
(out/'acceptance.lean').write_bytes(driver)
(out/'audit.lean').write_text('import PtxBinary32.Instructions\n'+''.join('#print axioms '+n+'\n' for n in names))
report={'schema':'ptxlean.binary32-review-probes/v1','model_calls':0,'started_at':now(),'replay':str(replay),'replay_result_sha256':sha((replay/'result.json').read_bytes()),'candidate_patch_sha256':result['patch_sha256'],'source_sha256':sha(original),'driver_sha256':sha(driver),'script_sha256':sha(Path(__file__).read_bytes()),'audit_declarations':names,'commands':[],'qualification':'One omitted-operand-read metadata defect; not completeness of the evaluator. Builds reuse coordinator fresh-replay dependencies, not worker artifacts.'}
def save(): (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name,argv,cwd,env=None):
    start=now(); r=subprocess.run(argv,cwd=cwd,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (out/(name+'.stdout.log')).write_text(r.stdout); (out/(name+'.stderr.log')).write_text(r.stderr)
    report['commands'].append({'name':name,'argv':list(map(str,argv)),'cwd':str(cwd),'returncode':r.returncode,'started_at':start,'finished_at':now(),'stdout':name+'.stdout.log','stderr':name+'.stderr.log'})
    save(); print(name,r.returncode,flush=True); return r
try:
    path=run('environment',['lake','env','printenv','LEAN_PATH'],project); assert path.returncode==0
    binary=run('compiler',['lake','env','which','lean'],project); assert binary.returncode==0
    lean=binary.stdout.strip(); leanpath=path.stdout.strip()
    assert all(Path(s).is_absolute() for s in leanpath.split(':') if s), 'Absolute Lake paths required'
    before='(if executed then i.left.reads ++ i.right.reads else [])'
    assert original.decode().count(before)==1
    mutant=original.decode().replace(before,'(if executed then ([] : List Scalar.Register) else [])')
    (out/'omit-operand-reads.patch').write_text(''.join(difflib.unified_diff(original.decode().splitlines(True),mutant.splitlines(True),fromfile='a/PtxBinary32/Instructions.lean',tofile='b/PtxBinary32/Instructions.lean')))
    for name,content in [('control',original),('omit-operand-reads',mutant.encode())]:
        overlay=out/name; module=overlay/'PtxBinary32/Instructions.lean'; module.parent.mkdir(parents=True); module.write_bytes(content)
        # Lean chooses the first package root containing this module prefix.
        # Copy only the reviewed numerical parent artifacts from fresh replay.
        for artifact in (project/'.lake/build/lib/lean').glob('PtxBinary32.*'):
            if artifact.is_file(): shutil.copy2(artifact, overlay/artifact.name)
        env=os.environ.copy(); env['LEAN_PATH']=str(overlay)+':'+leanpath
        assert run(name+'-build',[lean,'-o','PtxBinary32/Instructions.olean','PtxBinary32/Instructions.lean'],overlay,env).returncode==0
        audit=run(name+'-audit',[lean,str(out/'audit.lean')],overlay,env); assert audit.returncode==0; audit_dependencies(audit.stdout,names)
        accept=run(name+'-acceptance',[lean,str(out/'acceptance.lean')],overlay,env)
        assert accept.returncode==(0 if name=='control' else 1)
        if name!='control':
            expected_line=next(i for i,line in enumerate(driver.decode().splitlines(),1)
                               if '[.predicate 5, .word 3, .word 3], [.word 3], none' in line)
            errors=re.findall(r'^(.+):(\d+):(\d+): error: (.*)$',accept.stdout,re.M)
            assert len(errors)==1 and errors[0][0]==str(out/'acceptance.lean')
            assert int(errors[0][1])==expected_line and errors[0][3]=='Type mismatch'
            assert 'reads := [Register.predicate 5, Register.word 3, Register.word 3]' in accept.stdout
            report['detected_assertion']={'line':expected_line,'kind':'executed duplicate source-register reads','error_count':1}
    assert source.read_bytes()==original
    report['outcome']='pass: unchanged control and mutated source both compile with standard dependency reports; independent driver accepts control and rejects omitted operand reads.'
finally:
    report['finished_at']=now(); save()
