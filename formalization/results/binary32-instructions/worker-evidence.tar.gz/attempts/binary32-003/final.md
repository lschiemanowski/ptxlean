Appended the five requested named theorems to [Instructions.lean](/home/lothar/workspace/ptxlean/.formalization-runs/luna/attempts/binary32-001/worktree/integration/torchlean/PtxBinary32/Instructions.lean), leaving the reviewed core and existing examples unchanged. Their conclusions contain the explicit expected bits and cover signed zero, subnormal addition, negated guard execution and skip, and aliased addition.

Both checks passed:

- `lake build PtxBinary32.Instructions`
- `lake env lean PtxBinary32/Instructions.lean`

The audit of these five theorems and the required core theorems found only the permitted dependencies: `propext`, `Classical.choice`, and `Quot.sound`. No placeholders or new axioms were added.