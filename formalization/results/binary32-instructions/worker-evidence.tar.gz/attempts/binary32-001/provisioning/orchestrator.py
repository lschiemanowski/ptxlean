#!/usr/bin/env python3
"""Coordinator-only two-phase provisioning; --prepare-only never calls a model.

Dispatch is a separate explicit invocation. The immutable task base supplies the
worker_run helper code; no mutable coordinator module is imported for dispatch.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path('/home/lothar/workspace/ptxlean')
PROJECT = 'integration/torchlean'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args], stderr=subprocess.PIPE)


def load_runner(root, task, target):
    base = task.get('base_commit', '')
    if not re.fullmatch(r'[0-9a-f]{40}', base):
        raise ValueError('Task requires an exact committed base')
    raw = git(root, 'show', base + ':scripts/worker_run.py')
    target.write_bytes(raw)
    spec = importlib.util.spec_from_file_location('pinned_worker_run', target)
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    runner.validate_task(task, root)
    if runner.replay_project(task) != PROJECT:
        raise ValueError('This bounded provisioner handles integration/torchlean only')
    allowed = task['allowed_paths']
    if len(allowed) != 1 or not allowed[0].startswith(PROJECT + '/') or not allowed[0].endswith('.lean'):
        raise ValueError('Expected exactly one allowed new integration Lean module')
    if git(root, 'ls-tree', base, '--', allowed[0]).strip():
        raise ValueError('Allowed module must be new at the task base')
    return runner, raw


def check_clean(runner, task, worktree, manifest):
    candidate, boundary = runner.patch_and_boundary(worktree, task['base_commit'], task['allowed_paths'], PROJECT)
    if candidate or not boundary['eligible_for_review'] or runner.changed_sources(worktree, task):
        raise ValueError('Provisioning changed tracked/task sources or created non-cache files')
    for dependency in manifest['dependencies']:
        target = Path(dependency['destination'])
        if any(p.is_symlink() for p in [target, *target.parents] if p != worktree and worktree in p.parents):
            raise ValueError('Provisioned dependency destination must not be a symlink')
        if git(target, 'rev-parse', 'HEAD').decode().strip() != dependency['revision']:
            raise ValueError('Provisioned dependency revision changed: ' + dependency['name'])
        if git(target, 'status', '--porcelain', '--untracked-files=no').strip():
            raise ValueError('Provisioned dependency tracked source changed: ' + dependency['name'])
    return boundary


def prepare(args, runner, task, runner_bytes):
    root, campaign = args.root.resolve(), args.campaign.resolve()
    prompt = runner.task_prompt(task) + '''
Coordinator provisioning has prepared independent dependency checkouts and the
binary32 foundation in this worktree. Use explicit commands from
integration/torchlean when building the requested module. Only your one allowed
new module is an output. Generated caches may be written only in this worktree's
root .lake and integration/torchlean/.lake directories. Do not modify package
sources, manifests, root/shared dependencies, other worktrees, or symlink build
outputs into them. Do not update dependencies. Report a missing prerequisite.
'''
    directory = runner.new_attempt(campaign, args.attempt, task, prompt)
    worktree = directory / 'worktree'
    provision = directory / 'provisioning'
    provision.mkdir()
    (provision / 'worker_run.py').write_bytes(runner_bytes)
    (provision / 'orchestrator.py').write_bytes(Path(__file__).read_bytes())
    inputs = runner.project_inputs(task, root)
    manifest = {
        'schema_version': 1, 'kind': 'coordinator-worker-provisioning',
        'state': 'preparing', 'model_calls_during_preparation': 0,
        'attempt': args.attempt, 'base_commit': task['base_commit'],
        'task_sha256': digest(json.dumps(task, sort_keys=True).encode()),
        'prompt_sha256': digest(prompt.encode()), 'runner_sha256': digest(runner_bytes),
        'orchestrator_sha256': digest(Path(__file__).read_bytes()),
        'worktree': str(worktree), 'project_inputs': inputs,
        'started_at': runner.now(), 'commands': [], 'dependencies': [],
        'qualification': 'Preparation is not model dispatch, proof acceptance, or a reserved campaign call.',
    }
    manifest_path = provision / 'manifest.json'
    runner.atomic_json(manifest_path, manifest)

    def command(argv, name, cwd=worktree, allow_failure=False):
        entry = {'argv': [str(a) for a in argv], 'cwd': str(cwd), 'log': name + '.log',
                 'started_at': runner.now(), 'state': 'running', 'exit_code': None}
        manifest['commands'].append(entry)
        runner.atomic_json(manifest_path, manifest)
        try:
            with (provision / entry['log']).open('wb') as output:
                result = subprocess.run(entry['argv'], cwd=cwd, stdout=output, stderr=subprocess.STDOUT)
            entry.update(state='completed', exit_code=result.returncode)
        except BaseException as error:
            entry.update(state='failed', error=f'{type(error).__name__}: {error}')
            raise
        finally:
            entry['finished_at'] = runner.now()
            log = provision / entry['log']
            if log.is_file():
                entry['log_sha256'] = digest(log.read_bytes())
            runner.atomic_json(manifest_path, manifest)
        if result.returncode and not allow_failure:
            raise ValueError(f'{name} failed with exit code {result.returncode}')

    try:
        command(['git', '-C', root, 'worktree', 'add', '--detach', worktree, task['base_commit']], 'worktree', cwd=root)
        with runner.worktree_locked(campaign, worktree):
            for dependency in inputs['dependencies']:
                name, revision = dependency['name'], dependency['revision']
                source = root / PROJECT / '.lake/packages' / name
                if not source.is_dir() or git(source, 'rev-parse', revision+'^{commit}').decode().strip() != revision:
                    raise ValueError(f'Missing local source prerequisite: {source} at {revision}')
                target = worktree / PROJECT / '.lake/packages' / name
                target.parent.mkdir(parents=True, exist_ok=True)
                command(['git', 'clone', '--no-hardlinks', '--no-checkout', '--', source, target], name+'-clone')
                command(['git', '-C', target, 'checkout', '--detach', revision], name+'-checkout')
                command(['git', '-C', target, 'remote', 'set-url', 'origin', dependency['url']], name+'-origin')
                manifest['dependencies'].append({**dependency,'source_repository':str(source),'destination':str(target)})
                runner.atomic_json(manifest_path, manifest)
            check_clean(runner, task, worktree, manifest)
            mathlib = next((d for d in inputs['dependencies'] if d['name']=='mathlib'), None)
            if mathlib:
                manifest['official_cache']={'source_revision':mathlib['revision'], 'failure_policy':'retain failure and continue source build'}
                command(['lake','exe','cache','get'],'mathlib-cache',cwd=worktree/PROJECT,allow_failure=True)
                manifest['official_cache']['exit_code']=manifest['commands'][-1]['exit_code']
                check_clean(runner, task, worktree, manifest)
            command(['lake','build','PtxBinary32'],'foundation-build',cwd=worktree/PROJECT)
            manifest['boundary']=check_clean(runner, task, worktree, manifest)
            manifest.update(state='prepared',finished_at=runner.now())
            runner.atomic_json(manifest_path,manifest)
    except BaseException as error:
        manifest.update(state='interrupted' if isinstance(error,KeyboardInterrupt) else 'failed',
                        error=f'{type(error).__name__}: {error}',finished_at=runner.now())
        runner.atomic_json(manifest_path,manifest)
        raise
    print(json.dumps({'state':'prepared','manifest':str(manifest_path),
                      'manifest_sha256':digest(manifest_path.read_bytes()),
                      'model_dispatched':False,'campaign_call_reserved':False},indent=2))


def dispatch(args, runner, task, runner_bytes):
    campaign = args.campaign.resolve()
    directory = campaign/'attempts'/args.attempt
    manifest_path = directory/'provisioning/manifest.json'
    manifest = runner.read_json(manifest_path)
    saved_task = runner.read_json(directory/'task.json')
    if task != saved_task or manifest['task_sha256'] != digest(json.dumps(task,sort_keys=True).encode()):
        raise ValueError('Task changed since preparation')
    if manifest['state'] != 'prepared':
        raise ValueError('Provisioning has not completed successfully')
    if manifest['runner_sha256'] != digest(runner_bytes) or (directory/'provisioning/worker_run.py').read_bytes()!=runner_bytes:
        raise ValueError('Pinned runner changed')
    if manifest['orchestrator_sha256'] != digest(Path(__file__).read_bytes()):
        raise ValueError('Orchestrator changed since preparation')
    if digest((directory/'provisioning/orchestrator.py').read_bytes()) != manifest['orchestrator_sha256']:
        raise ValueError('Archived orchestrator changed')
    for entry in manifest['commands']:
        if digest((directory/'provisioning'/entry['log']).read_bytes()) != entry['log_sha256']:
            raise ValueError('Provisioning log changed: '+entry['log'])
    prompt=(directory/'prompt.md').read_text()
    if digest(prompt.encode()) != manifest['prompt_sha256']:
        raise ValueError('Prompt changed since preparation')
    worktree=Path(manifest['worktree']).resolve()
    if worktree != (directory/'worktree').resolve():
        raise ValueError('Unexpected prepared worktree')
    command=[args.codex,'exec','--ignore-user-config','--model',runner.MODEL,
             '--approve-for-me','--json','--cd',str(worktree),
             '--output-last-message',str(directory/'final.md'),'-']
    with runner.worktree_locked(campaign,worktree):
        check_clean(runner,task,worktree,manifest)
        if (directory/'receipt.json').exists():
            raise ValueError('Attempt already dispatched; use the recorded repair workflow')
        # dispatch itself durably reserves the one campaign call before launching.
        receipt=runner.dispatch(task,campaign,args.attempt,directory,worktree,prompt,command,
            provisioning_manifest=str(manifest_path),provisioning_sha256=digest(manifest_path.read_bytes()),
            provisioning_runner_sha256=manifest['runner_sha256'],
            provisioning_orchestrator_sha256=manifest['orchestrator_sha256'])
    print(json.dumps(receipt,indent=2))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('task',type=Path)
    parser.add_argument('attempt')
    parser.add_argument('--root',type=Path,default=ROOT)
    parser.add_argument('--campaign',type=Path,default=ROOT/'.formalization-runs/luna')
    parser.add_argument('--codex',default='codex')
    phase=parser.add_mutually_exclusive_group(required=True)
    phase.add_argument('--prepare-only',action='store_true')
    phase.add_argument('--dispatch',action='store_true')
    args=parser.parse_args()
    if not re.fullmatch(r'[a-z0-9][a-z0-9_-]*',args.attempt):
        raise ValueError('Invalid attempt identifier')
    task=json.loads(args.task.read_text())
    with tempfile.TemporaryDirectory(prefix='ptxlean-pinned-runner-') as temporary:
        runner,raw=load_runner(args.root.resolve(),task,Path(temporary)/'worker_run.py')
        (prepare if args.prepare_only else dispatch)(args,runner,task,raw)


if __name__=='__main__':
    main()
