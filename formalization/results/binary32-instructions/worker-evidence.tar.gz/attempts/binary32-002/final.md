Implemented the binary32 instruction slice in [Instructions.lean](/home/lothar/workspace/ptxlean/.formalization-runs/luna/attempts/binary32-001/worktree/integration/torchlean/PtxBinary32/Instructions.lean).

The module defines the FP-specific instruction and occurrence types, exact `Results`-based `Eval`, target-qualified fetched `Step`, and the typed text encoder and decoder. The required guard, state frame, alias-safe destination result, leaf existence, fetch origin, and text round-trip/specification theorems are complete. Kernel-checked examples cover the distinguishing add and multiply bit patterns, signed zero, subnormal input, NaN envelope freedom, aliases, positive and negative predicates, and typed rejection cases.

Both requested checks passed:

- `lake build PtxBinary32.Instructions`
- `lake env lean PtxBinary32/Instructions.lean`

A temporary `/tmp` dependency audit found only `propext`, `Classical.choice`, and `Quot.sound` for the required public theorems. The forbidden-placeholder scan and `git diff --check` were clean.

The interpretation remains limited to `add.rn.f32` and `mul.rn.f32` under PTX ISA 9.4 and numeric `sm >= 20`. Immediate words are already-decoded exact binary32 bit literals; register declaration compatibility remains a frontend obligation. The conservative `Results` envelope does not claim a particular GPU’s result or NaN payload. The coordinator-owned independent acceptance driver was not part of this worker checkout and was not created or modified.