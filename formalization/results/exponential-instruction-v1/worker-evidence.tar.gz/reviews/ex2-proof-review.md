# Independent exponential candidate proof review

Decision: source/proof/API review passed; no substantive issue found.

Reviewed candidate: `.formalization-runs/luna/attempts/exponential-001/worktree/integration/torchlean/PtxBinary32/ExponentialInstruction.lean`, after repair attempt `exponential-002`.

SHA256: `2b5f1a0d063d0aa5349c32b6c40da81fc7f192b2bd8fa5b6c28596f7d9b4b5f7`.

Scope: read-only independent comparison against the frozen exponential instruction contract, coordinator acceptance driver, numerical provider, and `/tmp/ex2-candidate-001.lean`. Reviewed all-result preservation, true/false guards, original-state operand evaluation with source/destination aliases, actual PC fetch and target restrictions, state frame, event identity, conditional existence and its converse, complete proof terms, and typed decoder equivalence.

The sole change relative to the saved initial candidate is the proof of `Text.decode_iff`. The statement, all definitions, and other theorem statements/proofs are unchanged. The repaired proof exhausts mnemonic equality and the exact two-operand typed shape.

The candidate retains every numerical `Results` outcome. Its execution existence condition is precisely a disabled guard or a supported operand; it constructs numerical witnesses using the provider's `results_exists`, without assuming a desired output. Disabled guards skip arbitrary inputs, including positive finite operands outside the enabled fragment. Supported enabled operands are finite nonpositive values, infinities, and NaNs. This remains bounded instruction coverage, not full exponential coverage or hardware conformance.

No incomplete proof or additional assumption was found by source inspection. This review did not rerun the Lean build or dependency audit and changed no repository or worker artifacts. Fresh replay and exact dependency auditing are separate acceptance gates. The first replay encountered `/tmp` inode exhaustion; its logs were retained and another replay is underway. No replay success is asserted by this report.
