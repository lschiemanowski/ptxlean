# Independent bounded exponential source review

The proposed bounded `ex2.approx.f32` contract and the first Luna candidate's definitions pass source/definition review with the qualifications below. This report is not a Lean kernel-check result, acceptance decision, full instruction-coverage claim or hardware-conformance claim.

Reviewed candidate: `.formalization-runs/luna/attempts/exponential-001/worktree/integration/torchlean/PtxBinary32/ExponentialInstruction.lean`, SHA256 `146f6dfbc0de8a82efcaf0d763293c740fc74ea30afb98cd94b3fcfe6b301258`.

Shared numerical provider `PtxBinary32/Exponential.lean` SHA256: `cfa7217a180a328214e35534a197ae81fa1df5832c787cc5dbc70eb2a523c331`; worker and coordinator copies matched during review.

Pinned PTX ISA 9.4 source `.ptx-source/9.4/index.html` SHA256 verified directly: `0aa31c15735a30b5d7c0fa1fe02570dcd37fe80800afca74bcc96c9132b81fed`.

## Scope and findings

- Exact special cases override the approximate relation: either signed-zero input returns positive one, negative infinity returns positive zero, positive infinity returns positive infinity, and NaN returns a NaN. Any-NaN payload freedom is a conservative allowance, not a realizability claim.
- Strictly negative finite operands preserve every result of the shared conservative ULP envelope. Its union of center-spacing and output-spacing conventions and nearest-even reference rounding are explicit interpretations. NVIDIA's wording does not settle the ULP evaluation point in the inspected instruction section. Inclusion of these two conventions does not establish all possible interpretations or unique source meaning.
- Positive finite operands are unsupported, including positive operands whose exponential would remain finite. This is a formalization coverage restriction, not PTX undefined behavior. The fragment belongs outside the accepted full-form ledger and its counts.
- No FTZ behavior is implemented. The selected ISA-exactly-9.4 and SM-at-least-20 policy preserves subnormals. These are project restrictions, not ex2's minimum instruction conditions: ex2 predates PTX 1.4, while its explicit approx modifier was introduced in 1.4.
- The candidate's disabled evaluation requires only a false guard and therefore skips unsupported operands too. Its enabled evaluation uses all shared provider Results for the incoming source, allowing register aliasing and changing only the destination and PC. Occurrence reads/writes and absence of memory effects match the contract.
- Existence is exposed exactly as disabled guard or supported operand. The fetched Step requires the selected target and the actual instruction at the current PC. There is no hidden unconditional totality assumption.
- The typed decoder accepts the exact mnemonic and unary word-source/register-destination shape. This is not a register-declaration checker or raw floating-literal parser; source words represent compatible float/bits registers or already decoded exact binary32 literals.

Source anchors examined: `floating-point-instructions-ex2`, `predicated-execution`, `operand-type-information`, `source-operands`, `destination-operands`, `fundamental-types`, `instruction-statements`, and `floating-point-constants`.

The initially reviewed candidate was mechanically failing in `Text.decode_iff` and was not accepted. The coordinator subsequently reports that the final candidate repairs only that proof, with an independent proof reviewer confirming unchanged definitions and theorem statements. This semantic review carries over on that stated byte/structure comparison; it does not independently claim a final candidate build or dependency audit.
