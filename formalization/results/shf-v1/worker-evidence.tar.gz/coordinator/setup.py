from pathlib import Path
import json,re,time,hashlib,subprocess
out=Path('.formalization-runs/shf-v1');out.mkdir(exist_ok=True);(out/'start.json').write_text(json.dumps({'epoch':time.time()})+'\n')
c=Path('formalization/contracts/prmt-v1.md').read_text().replace('Prmt32','Shf32').replace('prmt','shf').replace('data-movement-and-conversion-instructions-shf','logic-and-shift-instructions-shf').replace('SM >= 20','SM >= 32').replace('20 ≤ target.sm','32 ≤ target.sm').replace('| permute','| leftClamp | leftWrap | rightClamp | rightWrap')
c=c.replace('Selected spellings: shf.b32.','Selected spellings: shf.l.clamp.b32, shf.l.wrap.b32, shf.r.clamp.b32, shf.r.wrap.b32.\nOperation constructors correspond in that order.')
a=c.index('Select each of four output bytes');b=c.index('\n\nThe exact slice',a)
c=c[:a]+'''The first word a is the LOW half and the second word b is the HIGH half of a
64-bit concatenation. Left funnel shift returns the HIGH 32 bits of the shifted
concatenation; right funnel shift returns the LOW 32 bits. The control is an
unsigned 32-bit count: clamp uses min(c,32), wrap uses c modulo 32. Count 32 in
clamp mode returns a for left and b for right; wrap count 32 acts like zero.
All four selected forms were introduced in PTX 3.1 and require SM32 or higher.
The four equations below use zero-filling BitVec shifts by Nat amounts, which
produce zero at count 32. They prescribe results, not an implementation body.''' +c[b:]
a=c.index('theorem compute_bit');b=c.index('\ntheorem results_iff',a)
laws=''
for op,n,direction in [('leftClamp','min c.toNat 32','left'),('leftWrap','c.toNat % 32','left'),('rightClamp','min c.toNat 32','right'),('rightWrap','c.toNat % 32','right')]:
 rhs=f'(b <<< ({n})) ||| (a >>> (32 - ({n})))' if direction=='left' else f'(b <<< (32 - ({n}))) ||| (a >>> ({n}))'
 laws+=f'theorem compute_{op} (a b c : Word) :\n    compute .{op} a b c = {rhs}\n\n'
c=c[:a]+laws+c[b:];c=c.replace('pointwise theorem describes the required bits','four result equations describe the required words').replace('fixed output law','fixed output laws')
Path('formalization/contracts/shf-v1.md').write_text(c)
protocol='''# Funnel-shift family protocol

The coordinator supplies complete result equations and shared execution interfaces.
Luna chooses the computation and proves all four equations plus the common guarded
execution, existence, frame and exact typed-decoder obligations. This is assisted
formalization, not unsupervised interpretation of the manual.

Freeze contracts and checks before dispatch. Concrete expected words come from an
independent 64-bit integer concatenation oracle, covering all effective counts,
large counts, distinct source halves, guards, aliases, malformed operands and target
limits. Before dispatch, cross-check that oracle against the specified 32-bit
shift formulas. This arithmetic preflight does not preflight the full Lean driver.
After dispatch, retain the initial worker outcome before any feedback. Fresh replay
must check the unchanged drivers and audit every public definition and theorem.

Review the exact candidate and pinned source through the existing GLM route once,
retaining the advisory verdict separately from Lean validity and coordinator source
review. Check deliberate computation faults against the frozen concrete expectations.
Integrate only a fully proved candidate; report any repairs or remaining obligations.
Record calls, local repairs, reported usage/cost and coordinator preparation. Retain
vendor-bearing material locally; publish only project-authored evidence and hashes.
The existing campaign check-in threshold applies. No hardware conformance claim.
'''
Path('formalization/contracts/shf-v1-protocol.md').write_text(protocol)
block=c.split('```lean\n')[1].split('```')[0];ths=re.findall(r'^theorem (\S+)\s+([\s\S]*?)(?=^theorem |\Z)',block,re.M);assert len(ths)==21
head='import Ptx.Shf32\nopen Ptx\nset_option linter.unusedVariables false\nset_option maxRecDepth 4096\nnamespace Ptx.Scalar.Shf32.Acceptance\n\n'
univ=head
for name,statement in ths:
 s=statement.strip();level=0
 for pos,ch in enumerate(s):
  if ch in '([{⦃':level+=1
  elif ch in ')]}⦄':level-=1
  elif ch==':' and level==0:break
 else:raise ValueError(s)
 univ+='example : ∀ '+s[:pos]+','+s[pos+1:]+'\n  := @'+name+'\n\n'
mask=(1<<32)-1
ops=['leftClamp','leftWrap','rightClamp','rightWrap']
def oracle(op,a,b,c):
 n=min(c,32) if 'Clamp' in op else c%32
 joined=(b<<32)|a
 return ((joined<<n)>>32)&mask if op.startswith('left') else (joined>>n)&mask
def formula(op,a,b,c):
 n=min(c,32) if 'Clamp' in op else c%32
 return (((b<<n)|(a>>(32-n))) if op.startswith('left') else ((b<<(32-n))|(a>>n)))&mask
cases=[]
for op in ops:
 for a,b in [(0x89abcdef,0x12345678),(0,mask),(mask,0),(1,0x80000000)]:
  for count in list(range(34))+[63,64,65,255,256,0x80000000,mask]:
   expect=oracle(op,a,b,count);assert expect==formula(op,a,b,count)
   cases.append((op,a,b,count,expect))
con=head+'-- Expected words generated independently by joining two Python integers into 64 bits.\n'
for op,a,b,count,v in cases:con+=f'example : compute .{op} {hex(a)} {hex(b)} {hex(count)} = ({hex(v)} : Word) := by decide\n'
con+='\nexample : SupportedTarget ⟨94,32⟩ := by constructor <;> decide\nexample : ¬ SupportedTarget ⟨94,31⟩ := by intro h; have := h.2; omega\nexample : ¬ SupportedTarget ⟨93,90⟩ := by intro h; have := h.1; contradiction\n'
for op,sp in zip(ops,['shf.l.clamp.b32','shf.l.wrap.b32','shf.r.clamp.b32','shf.r.wrap.b32']):
 con+=f'''example : Text.decode ⟨.pred 3 false, "{sp}", [.word (.reg 0), .word (.reg 0), .word (.reg 0), .word (.reg 0)]⟩ = .ok (⟨.pred 3 false, .{op}, 0, .reg 0, .reg 0, .reg 0⟩ : Instr) := by decide
example : Text.decode ⟨.always, "{sp}", []⟩ = .error (.invalidOperands "{sp}") := by decide
example : Text.decode ⟨.always, "{sp}", [.word (.imm 0), .word (.reg 1), .word (.reg 2), .word (.reg 3)]⟩ = .error (.invalidOperands "{sp}") := by decide
example : Text.decode ⟨.always, "{sp}", [.word (.reg 0), .word (.imm 1), .word (.imm 2), .word (.imm 0xffffffff)]⟩ = .ok (⟨.always, .{op}, 0, .imm 1, .imm 2, .imm 0xffffffff⟩ : Instr) := by decide
'''
for sp in ['shf.l.b32','shf.l.clamp.b64','shf.r.wrap.u32','unknown']:
 con+=f'example : Text.decode ⟨.always, "{sp}", []⟩ = .error (.unsupportedMnemonic "{sp}") := by decide\n'
old=Path('formalization/checks/prmt-concrete-v1.lean').read_text();tail=old[old.index('private def incoming'):old.index('end Ptx.Scalar.Prmt32.Acceptance')].replace('.permute','.leftWrap')
con+=tail+'end Ptx.Scalar.Shf32.Acceptance\n'
Path('formalization/checks/shf-v1.lean').write_text(univ+'end Ptx.Scalar.Shf32.Acceptance\n');Path('formalization/checks/shf-concrete-v1.lean').write_text(con)
(out/'oracle-cases.json').write_text(json.dumps(cases,indent=2)+'\n');(out/'preflight.json').write_text(json.dumps({'arithmetic_cases':len(cases),'oracle':'64-bit integer concatenate/shift/extract','cross_check':'separate 32-bit shift-or formula','pass':True,'full_lean_driver_preflight':False})+'\n')
Path('stratic/descriptions/shf.md').write_text('''# Funnel shifts and rotations

A funnel shift joins two 32-bit words, shifts that 64-bit value, and returns
one 32-bit half. The first source supplies the low half; the second supplies
the high half. Left shifts return the high half and right shifts return the low
half. Bits entering the combined value are zero.

The count is an unsigned 32-bit word. Clamp mode caps it at 32; wrap mode uses
its remainder after division by 32. At count zero, left returns the second
source and right returns the first. At clamped count 32 these choices reverse;
wrapped count 32 acts like zero. Every source and count bit pattern is allowed.

Reading the same word as both sources in wrap mode rotates its bits: bits shifted
out of one end reappear at the other end. The rotation example uses an input
register twice and overwrites that register, then exits. Its result is specified
by Lean's standard word rotation, for arbitrary input and count. It provides a
finite execution witness and a correctness result for every completed execution,
while preserving memory and other registers. It models a sequential register-only
kernel; there is no device launch or hardware-conformance claim.

The four spellings are `shf.l.clamp.b32`, `shf.l.wrap.b32`, `shf.r.clamp.b32`
and `shf.r.wrap.b32`. A typed decoder accepts exactly a word-register destination
and three word operands, preserving the true-or-false execution guard. Immediates
are already converted to words; raw text and register declarations are outside
this boundary. Sources are read before any destination write, allowing repeats
and overlap. Executed instructions retain ordered source reads; skipped
instructions retain only the guard read and advance only the program counter.
Memory, address registers, predicates and other value registers are unchanged.

These forms were introduced in PTX 3.1 and require SM32 or higher. Fetched steps
require ISA exactly 9.4 and numeric SM at least 32, even when skipped. This is a
feature threshold rather than validation of architecture names. Universal result,
execution and decoder proofs establish the Lean contract. Reviewing that contract
against NVIDIA's documented meaning remains a separate obligation.
''')
d=json.loads(Path('stratic/descriptions/prmt.json').read_text());d.update(id='shf',summary=['Shift two joined words and return the high half for left shifts or low half for right shifts.','Admit every unsigned count, capping at 32 in clamp mode or reducing modulo 32 in wrap mode.','Use repeated inputs to verify a register-only rotation kernel with finite execution and preserved memory.'],realization='unimplemented',remaining='Frozen result and execution contracts; worker implementation, independent review, and rotation example are pending.',links=[]);Path('stratic/descriptions/shf.json').write_text(json.dumps(d,indent=2)+'\n')
print(len(cases),'arithmetic checks; 21 universal obligations')
