import Ptx.Pure32
import Ptx.ScalarText

namespace Ptx.Scalar.Shf32

private def w0 : Fin 3 := ⟨0, by decide⟩
private def w1 : Fin 3 := ⟨1, by decide⟩
private def w2 : Fin 3 := ⟨2, by decide⟩

def SupportedTarget (target : Ptx.Target) : Prop := target.isa = 94 ∧ 32 ≤ target.sm

inductive Operation where
  | leftClamp | leftWrap | rightClamp | rightWrap
  deriving DecidableEq, Repr

structure Instr where
  guard : Scalar.Guard := .always
  operation : Operation
  destination : Nat
  first : Scalar.Operand32
  second : Scalar.Operand32
  control : Scalar.Operand32
  deriving DecidableEq, Repr

def compute (op : Operation) (a b c : Word) : Word :=
  let n := match op with
    | .leftClamp | .rightClamp => min c.toNat 32
    | .leftWrap | .rightWrap => c.toNat % 32
  match op with
  | .leftClamp | .leftWrap => (b <<< n) ||| (a >>> (32 - n))
  | .rightClamp | .rightWrap => (b <<< (32 - n)) ||| (a >>> n)

def family : Pure32.Family Operation :=
  Pure32.Family.ofFunction (fun _ => 3) (fun _ => 0)
    (fun op words _ => compute op (words w0) (words w1) (words w2))
    (fun target _ => SupportedTarget target)

def lower (i : Instr) : Pure32.Instr family where
  guard := i.guard
  operation := i.operation
  destination := i.destination
  words := fun j => if j.val = 0 then i.first else if j.val = 1 then i.second else i.control
  predicates := Fin.elim0

def result (i : Instr) (s : Scalar.State) : Word :=
  compute i.operation (i.first.eval s) (i.second.eval s) (i.control.eval s)

abbrev Occurrence := Pure32.Occurrence family
abbrev Eval (i : Instr) := Pure32.Eval (lower i)
abbrev Step (target : Ptx.Target) (program : List Instr) := Pure32.Step target (program.map lower)

def occurrence (s : Scalar.State) (i : Instr) (executed : Bool) : Occurrence :=
  Pure32.occurrence s (lower i) executed

theorem results_iff (op : Operation) (words : Fin 3 → Word) (predicates : Fin 0 → Bool) (value : Word) :
    family.Results op words predicates value ↔ value = compute op (words 0) (words 1) (words 2) := by
  cases op <;> simp [family, Pure32.Family.ofFunction, compute, w0, w1, w2]

theorem lower_operation (i : Instr) : (lower i).operation = i.operation := rfl

theorem lower_fields (i : Instr) :
    (lower i).guard = i.guard ∧ (lower i).destination = i.destination ∧
    (lower i).words (⟨0, by decide⟩ : Fin 3) = i.first ∧
    (lower i).words (⟨1, by decide⟩ : Fin 3) = i.second ∧
    (lower i).words (⟨2, by decide⟩ : Fin 3) = i.control := by simp [lower]

theorem eval_true_iff (i : Instr) (s next : Scalar.State) (event : Occurrence)
    (enabled : i.guard.eval s = true) :
    Eval i s next event ↔
      next = Pure32.write s i.destination (result i s) ∧ event = occurrence s i true := by
  change Pure32.Eval (lower i) s next event ↔ _
  rw [Pure32.eval_true_iff (lower i) s next event enabled]
  constructor
  · rintro ⟨value, hres, hnext, hevent⟩
    have hv : value = result i s := by
      simpa [family, lower, Pure32.Family.ofFunction, Pure32.Instr.wordValues,
        Pure32.Instr.predicateValues, result, w0, w1, w2] using hres
    subst value
    exact ⟨hnext, hevent⟩
  · rintro ⟨hnext, hevent⟩
    refine ⟨result i s, ?_, hnext, hevent⟩
    simp [family, lower, Pure32.Family.ofFunction, Pure32.Instr.wordValues,
      result, w0, w1, w2]

theorem eval_false_iff (i : Instr) (s next : Scalar.State) (event : Occurrence)
    (disabled : i.guard.eval s = false) :
    Eval i s next event ↔
      next = {s with pc := s.pc + 1} ∧ event = occurrence s i false := by
  exact Pure32.eval_false_iff (lower i) s next event disabled

theorem eval_destination (i : Instr) (s next : Scalar.State) (event : Occurrence)
    (evaluated : Eval i s next event) (enabled : i.guard.eval s = true) :
    next.regs i.destination = result i s := by
  rcases (eval_true_iff i s next event enabled).mp evaluated with ⟨rfl, _⟩
  simp [Pure32.write]

theorem eval_frame (i : Instr) (s next : Scalar.State) (event : Occurrence)
    (evaluated : Eval i s next event) :
    next.pc = s.pc + 1 ∧ next.memory = s.memory ∧ next.addrs = s.addrs ∧ next.preds = s.preds :=
  Pure32.eval_frame evaluated

theorem eval_other (i : Instr) (s next : Scalar.State) (event : Occurrence) (other : Nat)
    (evaluated : Eval i s next event) (different : other ≠ i.destination) :
    next.regs other = s.regs other := Pure32.eval_other evaluated different

theorem eval_event (i : Instr) (s next : Scalar.State) (event : Occurrence)
    (evaluated : Eval i s next event) :
    event = occurrence s i (i.guard.eval s) := by
  simpa [occurrence, lower] using Pure32.eval_event evaluated

theorem eval_deterministic (i : Instr) (s next₁ next₂ : Scalar.State) (event₁ event₂ : Occurrence)
    (left : Eval i s next₁ event₁) (right : Eval i s next₂ event₂) :
    next₁ = next₂ ∧ event₁ = event₂ := by
  apply Pure32.eval_deterministic (i := lower i) (left := left) (right := right)
  intro words predicates a b ha hb
  exact ha.trans hb.symm

theorem eval_exists (i : Instr) (s : Scalar.State) : ∃ next event, Eval i s next event :=
  Pure32.eval_exists (lower i) s

theorem step_origin (target : Ptx.Target) (program : List Instr)
    (s next : Scalar.State) (event : Occurrence) (stepped : Step target program s next event) :
    SupportedTarget target ∧ ∃ i, program[s.pc]? = some i ∧
      event.pc = s.pc ∧ event.instruction = lower i ∧ Eval i s next event := by
  obtain ⟨j, fetch, supported, pc, ins, evaluated⟩ := Pure32.step_origin stepped
  have original : ∃ i, program[s.pc]? = some i ∧ lower i = j := by
    cases hx : program[s.pc]? with
    | none => simp [hx] at fetch
    | some i =>
      have hm : some (lower i) = some j := by simpa [hx] using fetch
      exact ⟨i, by simp, Option.some.inj hm⟩
  obtain ⟨i, fetchi, eq⟩ := original
  have ev : Eval i s next event :=
    Eq.mp (congrArg (fun x : Pure32.Instr family => Pure32.Eval x s next event) eq.symm) evaluated
  exact ⟨supported, i, fetchi, pc, ins.trans eq.symm, ev⟩

theorem step_exists (target : Ptx.Target) (program : List Instr) (s : Scalar.State) (i : Instr)
    (supported : SupportedTarget target) (fetch : program[s.pc]? = some i) :
    ∃ next event, Step target program s next event := by
  have mapped : (program.map lower)[s.pc]? = some (lower i) := by simp [fetch]
  exact Pure32.step_exists (lower i) mapped supported

theorem step_no_fetch (target : Ptx.Target) (program : List Instr)
    (s next : Scalar.State) (event : Occurrence) (missing : program[s.pc]? = none) :
    ¬ Step target program s next event := by
  exact Pure32.step_no_fetch (program := program.map lower) (s := s) (by simpa using missing)

theorem step_unsupported_target (target : Ptx.Target) (program : List Instr)
    (s next : Scalar.State) (event : Occurrence) (unsupported : ¬ SupportedTarget target) :
    ¬ Step target program s next event := by
  intro h
  obtain ⟨_, _, admitted, _⟩ := h
  exact unsupported admitted


theorem compute_leftClamp (a b c : Word) :
    compute .leftClamp a b c = (b <<< (min c.toNat 32)) ||| (a >>> (32 - (min c.toNat 32))) := rfl

theorem compute_leftWrap (a b c : Word) :
    compute .leftWrap a b c = (b <<< (c.toNat % 32)) ||| (a >>> (32 - (c.toNat % 32))) := rfl

theorem compute_rightClamp (a b c : Word) :
    compute .rightClamp a b c = (b <<< (32 - (min c.toNat 32))) ||| (a >>> (min c.toNat 32)) := rfl

theorem compute_rightWrap (a b c : Word) :
    compute .rightWrap a b c = (b <<< (32 - (c.toNat % 32))) ||| (a >>> (c.toNat % 32)) := rfl

namespace Text

def mnemonic : Operation → String
  | .leftClamp => "shf.l.clamp.b32"
  | .leftWrap => "shf.l.wrap.b32"
  | .rightClamp => "shf.r.clamp.b32"
  | .rightWrap => "shf.r.wrap.b32"

def supportedMnemonic (spelling : String) : Bool :=
  spelling == "shf.l.clamp.b32" || spelling == "shf.l.wrap.b32" ||
  spelling == "shf.r.clamp.b32" || spelling == "shf.r.wrap.b32"

def encode (i : Instr) : Scalar.Text.Statement :=
  ⟨i.guard, mnemonic i.operation,
    [.word (.reg i.destination), .word i.first, .word i.second, .word i.control]⟩

def decode (statement : Scalar.Text.Statement) : Except Scalar.Text.DecodeError Instr :=
  match statement.mnemonic, statement.operands with
  | "shf.l.clamp.b32", [.word (.reg d), .word a, .word b, .word c] => .ok ⟨statement.guard, .leftClamp, d, a, b, c⟩
  | "shf.l.wrap.b32", [.word (.reg d), .word a, .word b, .word c] => .ok ⟨statement.guard, .leftWrap, d, a, b, c⟩
  | "shf.r.clamp.b32", [.word (.reg d), .word a, .word b, .word c] => .ok ⟨statement.guard, .rightClamp, d, a, b, c⟩
  | "shf.r.wrap.b32", [.word (.reg d), .word a, .word b, .word c] => .ok ⟨statement.guard, .rightWrap, d, a, b, c⟩
  | spelling, _ => if supportedMnemonic spelling then .error (.invalidOperands spelling)
      else .error (.unsupportedMnemonic spelling)

theorem decode_encode (i : Instr) : decode (encode i) = .ok i := by
  cases i with
  | mk guard operation destination first second control => cases operation <;> rfl

theorem decode_iff (statement : Scalar.Text.Statement) (i : Instr) :
    decode statement = .ok i ↔ statement = encode i := by
  constructor
  · intro h
    rcases i with ⟨g, op, d, a, b, c⟩
    cases op <;> cases statement with
      | mk guard spelling operands =>
        unfold decode at h
        split at h
        all_goals first
          | (have hv := Except.ok.inj h; cases hv <;> all_goals simp_all [encode, mnemonic])
          | (split at h <;> simp_all [supportedMnemonic])
  · intro h
    subst statement
    exact decode_encode i

end Text
end Ptx.Scalar.Shf32
