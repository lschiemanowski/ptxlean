Implemented only [Ptx/Shf32.lean](/home/lothar/workspace/ptxlean/.formalization-runs/luna/attempts/shf-001/worktree/Ptx/Shf32.lean).

- `lake build Ptx.Shf32` passed.
- `lake env lean formalization/checks/shf-v1.lean` passed.
- The public definitions and proofs use only the allowed axioms: `propext`, `Quot.sound` (and `Text.decode` also uses `propext` alone).
- The additional concrete checker does **not** pass. Its expected values conflict with the specified equations: for example, `leftWrap` with `a = 0x7f80ff00`, `b = 0x80ff007f`, and `c = 0x3210` uses count 16 and computes `0x007f7f80`, while the checker expects `0x7f80ff00`. The checker also reports target-limit and decoder `Decidable` failures. I left the checker unchanged as required; this mismatch remains a blocker to treating that checker as passing.