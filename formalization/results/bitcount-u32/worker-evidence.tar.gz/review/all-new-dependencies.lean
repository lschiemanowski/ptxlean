import Ptx.IntegerBitCount
#print axioms Ptx.Scalar.unary_exec
#print axioms Ptx.Scalar.unary_false
#print axioms Ptx.Scalar.unary_preserves_other
#print axioms Ptx.Scalar.IntegerBitCount.unary_exec
#print axioms Ptx.Scalar.IntegerBitCount.unary_false
#print axioms Ptx.Scalar.IntegerBitCount.unary_preserves_other
#print axioms Ptx.Scalar.IntegerBitCount.takeWhile_length_le
#print axioms Ptx.Scalar.IntegerBitCount.takeWhile_length_eq_iff
#print axioms Ptx.Scalar.IntegerBitCount.popc_toNat
#print axioms Ptx.Scalar.IntegerBitCount.clz_toNat
#print axioms Ptx.Scalar.IntegerBitCount.popc_bound
#print axioms Ptx.Scalar.IntegerBitCount.clz_bound
#print axioms Ptx.Scalar.IntegerBitCount.popc_zero_iff
#print axioms Ptx.Scalar.IntegerBitCount.clz_width_iff
#print axioms Ptx.Scalar.UnaryOp.eval
#print axioms Ptx.Scalar.Text.unaryMnemonic
#print axioms Ptx.Scalar.IntegerBitCount.sampleState
