Work on the following bounded PTXLean task. Do not commit, prepare Stratic reviews, or modify files outside the task's allowed paths; the coordinator handles integration. Do not change theorem obligations or shared semantics to make a proof pass. If a prerequisite is missing, report it explicitly. No external model calls.

Implement exactly PTX clz.b32 and popc.b32 on the existing scalar foundation. Read pinned PTX9.4 HTML sections integer-arithmetic-instructions-popc (9.7.1.15, lines9685-9721) and integer-arithmetic-instructions-clz (9.7.1.16, lines9722-9764), the integer-arithmetic-instructions parent, operand-type-information, source-operands, destination-operands and predicated-execution. Each instruction has one b32 source and a u32 destination register; source may be register or immediate. Both introduced PTX2.0, require sm20+. Zero has popc0 and clz32. Every 32-bit input is allowed. Do not treat b64 or u32 mnemonic variants, other widths or modifiers as supported. The package's u32 name describes the result, not instruction spelling.

Add Ptx.Scalar.UnaryOp with constructors clz and popc, UnaryOp.eval : UnaryOp -> Word -> Word, and Op.unary32 (operation : UnaryOp) (destination : Nat) (source : Operand32). This is a one-source operation: do not invent a dummy binary operand or second machine. Extend actual eval, Op.reads/Op.writes, typed mnemonics (unaryMnemonic), decodeOp, encodeOp and supportedMnemonic. Preserve existing theorem statements and old semantics, including unsupported-under-false-guard behavior. Source operands are read from incoming state before the destination update even with aliasing. No memory access, no extra register writes, PC advances once, false guards read only their predicate. Preserve Text.decode_encode and Text.decodeOp_supported for the enlarged interface. Target/version facts must be documented; the existing memory-only eligibility mechanism must not be described as checking these arithmetic forms.

Create Ptx/IntegerBitCount.lean importing Ptx.ScalarText, namespace Ptx.Scalar.IntegerBitCount. Required named universal theorems with no extra input-domain/output premises:
* popc_toNat (a : Word) : (UnaryOp.eval .popc a).toNat = ((List.range 32).filter (fun i => a.getLsbD i)).length
* clz_toNat (a : Word) : (UnaryOp.eval .clz a).toNat = ((List.range 32).reverse.takeWhile (fun i => !a.getLsbD i)).length
* popc_bound (a : Word) : (UnaryOp.eval .popc a).toNat <= 32
* clz_bound (a : Word) : (UnaryOp.eval .clz a).toNat <= 32
* popc_zero_iff (a : Word) : UnaryOp.eval .popc a = 0 <-> a = 0
* clz_width_iff (a : Word) : UnaryOp.eval .clz a = 32 <-> a = 0
The list contracts mean counting all true bits at indices0..31 versus counting the initial false prefix at indices31..0; they prescribe mathematical meaning, not your evaluation algorithm. Source review remains separate from Lean proof checking.

Also supply unary_exec, unary_false and unary_preserves_other with the exact signatures below (the coordinator-owned acceptance file is not part of this pinned base). In particular unary_exec takes s, operation, destination, source, guard, true-guard proof, readOverride and states equality of eval's actual .next result to the incoming state updated only at PC and destination. unary_false has the same order with false-guard proof and advances only PC. unary_preserves_other takes s, operation, destination, other, source, guard, true-guard proof, other-not-destination proof, readOverride and shows the actual next state's other register unchanged. The exact declarations are:

theorem unary_exec (s : State) (operation : UnaryOp) (destination : Nat)
    (source : Operand32) (guard : Guard) (h : guard.eval s = true)
    (readOverride : Option Word) :
    eval readOverride ⟨guard, .unary32 operation destination source⟩ s =
      .next {s with pc := s.pc + 1,
        regs := update s.regs destination (operation.eval (source.eval s))}
        (occurrence s ⟨guard, .unary32 operation destination source⟩ true)

theorem unary_false (s : State) (operation : UnaryOp) (destination : Nat)
    (source : Operand32) (guard : Guard) (h : guard.eval s = false)
    (readOverride : Option Word) :
    eval readOverride ⟨guard, .unary32 operation destination source⟩ s =
      .next {s with pc := s.pc + 1}
        (occurrence s ⟨guard, .unary32 operation destination source⟩ false)

theorem unary_preserves_other (s : State) (operation : UnaryOp) (destination other : Nat)
    (source : Operand32) (guard : Guard) (h : guard.eval s = true)
    (different : other ≠ destination) (readOverride : Option Word) :
    (match eval readOverride ⟨guard, .unary32 operation destination source⟩ s with
      | .next next _ => next.regs other | _ => s.regs other) = s.regs other
 Arbitrary readOverride must not affect these non-memory instructions.

Include kernel-checked examples for zero, high bit, all ones, low bit and mixed patterns; source/destination overlap for both operations; true and false positive/negative guards; register/immediate decoding; malformed operands versus unsupported mnemonics. Do not modify independent checks. Preserve existing proofs instead of weakening their statements. Only edit Ptx/Scalar.lean, Ptx/ScalarText.lean, Ptx/IntegerBitCount.lean and, if needed, Ptx/ScalarRules.lean solely for mechanical proof repairs caused by the new unary constructor. All pre-existing theorem statements must remain unchanged. Do not modify Ptx.lean, Ptx/Audit.lean, descriptions, scripts, checks, toolchain or other files. If adding the constructor exposes a genuine downstream proof obligation outside these paths, report the exact failure rather than bypassing it. Coordinator handles common imports, audits and Stratic links.

No sorry, admit, new axioms, native_decide, external models or commits. Keep the solution small and readable. Run lake build, lake build Ptx.IntegerBitCount and lake env lean Ptx/IntegerBitCount.lean. The coordinator will separately run the frozen acceptance driver from outside your worktree; do not create or change that file. Inspect public theorem dependencies with a temporary /tmp driver. At end report exact changed definitions/theorems, checks and source qualifications, and any incomplete obligation. There is no arbitrary repair-attempt limit; report substantive obstacles instead of weakening the task.


Allowed paths:
Ptx/Scalar.lean
Ptx/ScalarText.lean
Ptx/ScalarRules.lean
Ptx/IntegerBitCount.lean

Pinned source inputs:
references/nvidia/ptx-isa-9.4/index.html

Continue the recorded attempt bitcount-002. Preserve its task obligations and finish the requested repair.

Feedback:
The second candidate compiles and its reviewed definitions and proofs are promising, but it does not yet satisfy the original public interface: unary_exec, unary_false and unary_preserves_other are present only in Ptx.Scalar, whereas the task requires them in Ptx.Scalar.IntegerBitCount. Expose the three originally specified theorems in that namespace with their original statements; wrappers around your existing checked general theorems are fine. Preserve the existing theorems and all numeric characterizations, old contracts, input domains and the original file allowlist. No proof holes, unchecked axioms or native_decide.

Our original acceptance driver also had an indentation error in a multiline record update. This is a coordinator error, recorded separately from your interface mismatch. The original driver and failed replay remain preserved. The corrected driver is formalization/checks/bitcount-u32-v2.lean in the coordinator checkout: its non-whitespace bytes are identical to v1. All its checks now pass except the three missing required names. No acceptance assertion or requested namespace has been changed.

Complete the namespace repair, explicitly compile the new module, inspect the dependencies, and run the existing checks. Continue in the same checkout; do not commit or invoke other models.
