Implemented the signed min/max leaf in [Ptx/SignedMinMax32.lean](/home/lothar/workspace/ptxlean/.formalization-runs/luna/attempts/signed-minmax32-001/worktree/Ptx/SignedMinMax32.lean). It uses signed `BitVec.toInt` comparisons, lowers instructions through `Pure32`, and provides the typed encoder, decoder, and required proofs.

Both `lake env lean Ptx/SignedMinMax32.lean` and `lake build Ptx.SignedMinMax32` pass. The `#print axioms` audit covered every public theorem: only `propext` and `Quot.sound` appear. The pinned PTX reference hash matches the contract. Only the allowed leaf file was created or modified.

I did not run the coordinator-owned acceptance driver; independent acceptance remains with the coordinator.