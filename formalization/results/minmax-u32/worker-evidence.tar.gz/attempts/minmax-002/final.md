I made the operation, mnemonic, and decoder changes, but the task is incomplete.

The existing `decodeOp_supported` proof times out after the decoder is expanded. Because `Ptx.ScalarText` does not compile, I could not compile `Ptx/IntegerMinMax.lean` or complete the requested algebraic proofs, execution theorem, and examples. No new theorem obligations were weakened. The pinned manual supports the exact `.u32` forms as PTX ISA 1.0 instructions for all target architectures; the existing eligibility checker does not establish arithmetic eligibility.

The requested checks did not pass: `lake build Ptx.ScalarText` times out at `decodeOp_supported`, and `lake env lean Ptx/IntegerMinMax.lean` cannot resolve `Ptx` until its imports build.