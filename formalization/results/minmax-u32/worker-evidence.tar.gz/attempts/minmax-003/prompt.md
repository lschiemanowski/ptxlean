Work on the following bounded PTXLean task. Do not commit, prepare Stratic reviews, or modify files outside the task's allowed paths; the coordinator handles integration. Do not change theorem obligations or shared semantics to make a proof pass. If a prerequisite is missing, report it explicitly. No external model calls.

Implement exactly PTX min.u32 and max.u32 on the existing scalar foundation. Read the pinned manual sections integer-arithmetic-instructions-min and integer-arithmetic-instructions-max (around HTML lines 9521-9684), plus the relevant integer operands/predication clauses. Do not treat other min/max types or modifiers as supported.

Extend Ptx.Scalar.BinOp with minU and maxU and the actual BinOp.eval cases. Extend the typed ScalarText mnemonics, decoder and encoder. Preserve all existing theorem statements, semantics of old operations, and typed-interface restrictions. Use the existing binary-operation/guard/register machinery; don't invent a second execution model. No unsigned-domain exclusions: all Word values, including the high bit, are covered. PTX1.0/all targets for these exact forms is a source condition; the existing eligibility checker covers memory only, do not pretend it validates arithmetic.

Create Ptx/IntegerMinMax.lean importing Ptx.ScalarText. In namespace Ptx.Scalar.IntegerMinMax prove min_toNat (a b : Word) : (BinOp.eval .minU a b).toNat = Nat.min a.toNat b.toNat and max_toNat analogously using Nat.max. Also prove general operand-membership, commutativity, idempotence and unsigned result bounds for both actual eval cases. Include at least one general execution theorem connecting the instruction to its destination for arbitrary state/operands and true guard; prove which components remain unchanged, false-guard behavior and correct use of incoming operands when source/destination overlap. Existing reusable facts may be used, but identify the exact facts rather than merely claiming coverage.

Include kernel-checked examples for high-bit unsigned comparisons, ties, register/immediate decoding, both source/destination overlap positions, false positive/negative guards, and malformed/unsupported text variants. Preserve decode_encode and decodeOp_supported for the expanded constructors. No sorry, admit, new axioms, native_decide, or assumptions of desired results. Do not modify Ptx.lean, Ptx/Audit.lean, scripts, descriptions or any other file. Coordinator integrates those. You may run lake build and lake env lean Ptx/IntegerMinMax.lean; include #print axioms for your public theorems in a temporary /tmp driver if needed. Toolchain is pinned. At end report exact definitions/theorems, checks run and source qualifications, including any uncompleted obligations. Do not call external models or commit.

This is exploratory capability evaluation. Take the repair steps needed; there is no fixed retry limit. A missing foundation or genuine source ambiguity must be reported instead of silently weakening the task.

Allowed paths:
Ptx/Scalar.lean
Ptx/ScalarText.lean
Ptx/IntegerMinMax.lean

Pinned source inputs:
references/nvidia/ptx-isa-9.4/index.html

Continue the recorded attempt minmax-002. Preserve its task obligations and finish the requested repair.

Feedback:
Your first substantive attempt is preserved but is not accepted: ScalarText does not build and the instruction module contains only two candidate numerical proofs. Continue the original task in this same checkout. A tactic timeout is not a reason to abandon the task or weaken a theorem. Diagnose whether the exhaustive decoder proof needs a more efficient proof or a local increase in Lean's deterministic heartbeat budget. Keep every existing statement and behavior intact. A larger proof-search budget does not replace checking the resulting proof.

Complete every original obligation: arbitrary-word numerical meaning, membership, commutativity, idempotence and unsigned bounds, actual execution/destination/frame, false guards, overlap and the requested boundary and text examples. Compile the module with `lake build Ptx.IntegerMinMax` (or build its imports before `lake env lean Ptx/IntegerMinMax.lean`), and run the existing project checks. Use a temporary driver to inspect dependencies. Do not add proof holes or unchecked axioms. Only the original three allowed paths may change; temporary files belong outside the checkout. Do not edit the coordinator's acceptance tests or commit.

The original task has no fixed retry or inference-time cap. Make the routine proof repairs yourself and report a genuinely missing prerequisite or unresolved source question precisely. Report what actually passes, and list remaining obligations if there is a substantive obstacle.
