Implemented the multiply-high slice in [Ptx/MulHi32.lean](/home/lothar/workspace/ptxlean/.formalization-runs/luna/attempts/mulhi32-001/worktree/Ptx/MulHi32.lean). The pinned PTX source hash matches the contract.

Both requested checks passed:

- `lake build Ptx.MulHi32`
- `lake env lean formalization/checks/mulhi32-v1.lean`

The public definition and theorem axiom audits report only `propext` where applicable, which is within the allowed set. No blockers found.