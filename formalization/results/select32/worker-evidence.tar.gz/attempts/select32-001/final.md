I wasn’t able to complete the task: `Ptx/Select32.lean` still fails to compile, so I can’t run the requested `lake build` or axiom inspection. The remaining proof obligations are:

- In `eval_true_iff`, show the lowered family result equals `result i s`, so the executed-state equality rewrites to the required form.
- In `step_origin`, recover the original fetched instruction and transport the event and evaluation proofs across `lower original = j`.
- In `step_unsupported_target`, convert the fetched family support proposition to `SupportedTarget target`.

The pinned reference hash matched the contract. I made no changes outside the allowed path.