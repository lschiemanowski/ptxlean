import Ptx.MulHi32
open Ptx.Scalar.MulHi32
example : compute .signed 0xffffffff 1 = 0 := by decide
