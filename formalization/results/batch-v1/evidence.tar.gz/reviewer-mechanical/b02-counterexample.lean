import Ptx.Brev32
set_option maxRecDepth 4096
open Ptx.Scalar.Brev32
example : compute .brev 1 = 2147483648 := by decide
