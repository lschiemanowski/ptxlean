import Ptx.MulHi32
open Ptx.Scalar.MulHi32
example : compute .signed 1 0xffffffff = 4294967295 := by decide
