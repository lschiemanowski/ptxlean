import Ptx.Bfe32
set_option maxRecDepth 4096
open Ptx.Scalar.Bfe32
example : compute .unsigned 1 256 1 = 1 := by decide
