import json,subprocess,sys,hashlib
from pathlib import Path
root=Path.cwd();out=root/'.formalization-runs/batch-v1';w=out/'preflight-worktree'
sys.path.insert(0,str(root/'scripts'));from check_implemented_forms import declaration_sites
from worker_replay import audit_dependencies,scan
configs=json.loads((out/'configs.json').read_text());records=[]
for c in configs:
 ns=c['ns'];p=w/f'Ptx/{ns}.lean';fixture=(out/f'{ns}-fixture.lean').read_text()
 p.write_text(fixture)
 r=subprocess.run(['lake','build',f'Ptx.{ns}'],cwd=w,capture_output=True,text=True);assert r.returncode==0
 r=subprocess.run(['lake','env','lean',str(root/f'formalization/checks/{c["id"]}-v1.lean')],cwd=w,capture_output=True,text=True);assert r.returncode==0,(c,r.stdout+r.stderr)
 declarations=[n for n,k,l in declaration_sites(fixture) if k in ('def','theorem')]
 driver=root/f'formalization/checks/{c["id"]}-v1.lean'
 audit=out/f'{c["id"]}-fixture-audit.lean';audit.write_text(f'import Ptx.{ns}\n'+''.join('#print axioms '+n+'\n' for n in declarations))
 r=subprocess.run(['lake','env','lean',str(audit)],cwd=w,capture_output=True,text=True);log=r.stdout+r.stderr;(out/f'{c["id"]}-fixture-audit.log').write_text(log);assert r.returncode==0; audit_dependencies(log,declarations)
 scan([p,driver])
 replacements={'brev32':('a.reverse','a'),'mulhi32':('a.toInt * b.toInt','(Int.ofNat a.toNat) * (Int.ofNat b.toNat)'),'bfe32':('b.toNat % 256','b.toNat')}
 old,new=replacements[c['id']];mutant=fixture.replace(old,new);assert mutant!=fixture
 (out/f'{ns}-mutant.lean').write_text(mutant);p.write_text(mutant)
 r=subprocess.run(['lake','build',f'Ptx.{ns}'],cwd=w,capture_output=True,text=True);(out/f'{c["id"]}-mutant-build.log').write_text(r.stdout+r.stderr);assert r.returncode==0,(c,r.stdout+r.stderr)
 r=subprocess.run(['lake','env','lean',str(driver)],cwd=w,capture_output=True,text=True);log=r.stdout+r.stderr;(out/f'{c["id"]}-mutant-driver.log').write_text(log)
 assert r.returncode!=0 and 'decide' in log and 'false' in log,(c,log)
 records.append({'task':c['id']+'-v1','fixture_sha256':hashlib.sha256(fixture.encode()).hexdigest(),'driver_sha256':hashlib.sha256(driver.read_bytes()).hexdigest(),'control_build':'pass','control_driver':'pass','control_audit':'pass','declarations':declarations,'mutant_build':'pass','mutant_driver':'rejects_false_assertion','mutant_sha256':hashlib.sha256(mutant.encode()).hexdigest()})
 p.write_text(fixture)
 print(c['id'],'control and mutation checks passed',flush=True)
(out/'preflight.json').write_text(json.dumps({'schema_version':1,'records':records,'qualification':'Coordinator-written fixtures instantiate the specified definitions and generic proof templates. Not model output or independent PTX correctness evidence. Prepared and checked before dispatch; excluded from worker base and inputs. Initial checker elaboration/recursion issues were fixed before freezing; logs retained.'},indent=2)+'\n')
