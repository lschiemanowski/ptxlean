import sys,json,subprocess,hashlib
from pathlib import Path
root=Path.cwd();out=root/'.formalization-runs/derived-v1';w=out/'preflight-worktree'
sys.path.insert(0,'scripts');from check_implemented_forms import declaration_sites
from worker_replay import audit_dependencies,scan
records=[]
for c in json.loads((out/'configs.json').read_text()):
 id,ns=c['id'],c['ns']; fixture=(out/f'{ns}-fixture.lean').read_text(); p=w/f'Ptx/{ns}.lean';p.write_text(fixture)
 driver=root/f'formalization/checks/{id}-v1.lean'
 checks=driver.read_text();concrete=checks[:checks.index('example : ∀')]+checks[checks.index('example : compute'):]
 concrete_path=root/f'formalization/checks/{id}-concrete-v1.lean';concrete_path.write_text(concrete)
 decl=[n for n,k,l in declaration_sites(fixture) if k in ('def','theorem')]
 audit=out/f'{id}-fixture-audit.lean';audit.write_text(f'import Ptx.{ns}\n'+''.join('#print axioms '+n+'\n' for n in decl))
 def run(args,name,ok=True):
  r=subprocess.run(args,cwd=w,capture_output=True,text=True);log=r.stdout+r.stderr;(out/(id+'-'+name+'.log')).write_text(log)
  assert (r.returncode==0)==ok,(name,log[-3000:]);return log
 run(['lake','build',f'Ptx.{ns}'],'control-build')
 run(['lake','env','lean',str(driver)],'control-driver')
 run(['lake','env','lean',str(concrete_path)],'control-concrete')
 log=run(['lake','env','lean',str(audit)],'control-audit');audit_dependencies(log,decl);scan([p,driver])
 if id=='bfi32':mutant=fixture.replace('c.toNat % 256','c.toNat')
 else:mutant=fixture.replace('then 4 else 0','then REPLACE else 0').replace('then 1 else 0','then 4 else 0').replace('then REPLACE else 0','then 1 else 0')
 (out/f'{ns}-mutant.lean').write_text(mutant);p.write_text(mutant)
 run(['lake','build',f'Ptx.{ns}'],'mutant-build')
 log=run(['lake','env','lean',str(audit)],'mutant-audit');audit_dependencies(log,decl)
 log=run(['lake','env','lean',str(concrete_path)],'mutant-concrete',False)
 assert 'false' in log and 'decide' in log
 run(['lake','env','lean',str(driver)],'mutant-driver',False)
 p.write_text(fixture)
 sha=lambda v:hashlib.sha256(v).hexdigest()
 records.append({'task':id+'-v1','fixture_sha256':sha(fixture.encode()),'mutant_sha256':sha(mutant.encode()),'driver_sha256':sha(driver.read_bytes()),'concrete_sha256':sha(concrete_path.read_bytes()),'control':'build, all universal signatures, concrete cases and exact dependency audit passed','mutant':'build and dependency audit passed; concrete false assertions and full semantic property driver rejected','declarations':decl})
 print(id,records[-1]['control'],flush=True)
(out/'preflight.json').write_text(json.dumps({'schema_version':1,'records':records,'qualification':'Coordinator-authored reference fixtures and concrete distinguishing checks, excluded from worker checkout and task sources. Draft fixture/proof and checker repairs occurred before freeze; none credited to Luna.'},indent=2)+'\n')
