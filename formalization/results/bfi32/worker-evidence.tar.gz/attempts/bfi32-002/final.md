The attempt is still incomplete. `lake build Ptx.Bfi32` fails in three places:

- `compute_bit`: the `BitVec.ofBoolListLE (List.ofFn ...)` construction does not yet reduce to the required `getLsbD` equation.
- `lower_fields` and `eval_true_iff`: the `Fin 4` projection for source index 3 does not reduce to `i.length`.

I have not run either frozen checker or the axiom audit because the module does not build. The only changed path is `Ptx/Bfi32.lean`.