Implemented the unary bit operations, `Pure32` lowering and execution proofs, and typed text interface in [Ptx/UnaryBits32.lean](/home/lothar/workspace/ptxlean/.formalization-runs/luna/attempts/unary-bits32-001/worktree/Ptx/UnaryBits32.lean).

- `lake build Ptx.UnaryBits32` succeeds.
- The public theorem axiom audit reports only `propext` and `Quot.sound` (and `propext` alone for the text decoder theorems).
- The immutable v1 driver still fails on its reported `Instr`, `Occurrence`, and `Text.decode` name ambiguities. I did not modify it; no v3 driver is present in `formalization/checks`.
- Only the allowed leaf file was edited. No placeholders, forbidden axioms, or commits were introduced.